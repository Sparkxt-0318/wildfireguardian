"""Publication-only layout sidecar. Preserves the canonical report and all original figures."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, fcntl, hashlib, importlib.util, json, os, shutil, sys
import numpy as np
ROOT=Path('/Users/jp/Documents/Codex/2026-10-30/work-in-the-wildfireguardian-repository-on/work/track-1b')
E=ROOT/'research/forecast-v2'; RUN=ROOT/'forecast/runs/20261030_perimeter_trained/execution_v3'
REPORT_SHA='56e7769084481167cc57d2d62510eef37cb4f7657826e9737985b77d9dd7dfc7'
RESULTS_SHA='083d06c50d44258a771793410eea513f297fbc587432df872b9ea8cc46b8b755'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def artist_data(fig):
    out=[]
    for ax in fig.axes:
        out.append(dict(xlim=list(ax.get_xlim()),ylim=list(ax.get_ylim()),lines=[dict(x=np.asarray(l.get_xdata()).tolist(),y=np.asarray(l.get_ydata()).tolist()) for l in ax.lines],collections=[hashlib.sha256(np.asarray(c.get_segments(),dtype=np.float64).tobytes()).hexdigest() for c in ax.collections if hasattr(c,'get_segments')],images=[dict(data=hashlib.sha256(np.asarray(im.get_array().data).tobytes()).hexdigest(),mask=hashlib.sha256(np.ma.getmaskarray(im.get_array()).tobytes()).hexdigest(),clim=list(im.get_clim()),cmap=im.get_cmap().name,extent=list(im.get_extent())) for im in ax.images]))
    return out

def layout_only(fig,name):
    fig.canvas.draw(); before=artist_data(fig)
    if name=='fig03_ablation_forest_plot':
        ax=fig.axes[0]; ticks=ax.get_xticks().copy(); labels=[v.get_text() for v in ax.get_xticklabels()]
        limits=ax.get_xlim(); ax.set_xticks(ticks,labels); ax.set_xlim(limits); fig.subplots_adjust(right=.91)
    elif name=='fig05_example_forecast_vs_perimeter':
        bars=[ax for ax in fig.axes if ax.get_ylabel()=='Cumulative probability or mapped (1)']; assert len(bars)==1
        bars[0].set_ylabel('Cumulative probability\nor mapped (1)')
    else: raise ValueError('Only the two declared figures may be rerendered')
    fig.canvas.draw(); after=artist_data(fig); assert before==after, 'Numerical artist state changed'
    return before

def main():
    p=argparse.ArgumentParser(); p.add_argument('--output',type=Path,required=True); a=p.parse_args()
    output=a.output.absolute(); parent=output.parent.resolve(); permitted=(E/'publication-render').resolve()
    assert parent==permitted and not output.exists() and not output.is_symlink()
    assert sha(E/'scripts/report.py')==REPORT_SHA and sha(E/'RESULTS.json')==RESULTS_SHA
    u=json.loads((ROOT.parent/'FREEZE_PARENT_VERIFICATION.json').read_text())['verified_file_sha256']; custody=json.loads((E/'executions/current_assessment_closed_custody.json').read_text())
    protected=dict(u,**custody['artifacts_sha256']); protected.update({str(p.relative_to(ROOT)):sha(p) for p in [E/'RESULTS.json',E/'FARSITE_SCORES.json',E/'FIGURE_QA_ORIGINAL.json']+list((E/'figures').glob('*.png'))+list((E/'figures').glob('*.svg'))})
    check=lambda:[n for n,h in protected.items() if sha(ROOT/n)!=h]
    assert len(u)==223 and not check(); results=json.loads((E/'RESULTS.json').read_text())
    record=dict(schema='wfg.publication-layout-sidecar/1',source_sha256=sha(__file__),canonical_results_sha256=RESULTS_SHA,canonical_report_source_sha256=REPORT_SHA,started_utc=datetime.now(timezone.utc).isoformat(),changes={'fig03_ablation_forest_plot':'Right margin .98 to .91; preserve original tick positions/text and all numeric artists.','fig05_example_forecast_vs_perimeter':'Insert one line break in the existing colorbar label; preserve all words and numeric artists.'},protected_artifacts_sha256=protected,figures={})
    with open('/tmp/wfg/HEAVY.lock','a+') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX); record['lease_acquired_utc']=datetime.now(timezone.utc).isoformat(); assert not check()
        permitted.mkdir(exist_ok=True); output.mkdir(exist_ok=False)
        sys.path.insert(0,str(E/'scripts')); sys.path.insert(0,str(ROOT/'forecast'))
        spec=importlib.util.spec_from_file_location('frozen_report_publication',E/'scripts/report.py'); report=importlib.util.module_from_spec(spec); spec.loader.exec_module(report)
        plt=report.style(); original_save=report.save
        def save(fig,out,name):
            state=layout_only(fig,name); original_save(fig,out,name); record['figures'][name]=dict(operation='LAYOUT_ONLY_RERENDER',numeric_artist_state_sha256=hashlib.sha256(json.dumps(state,sort_keys=True,allow_nan=True).encode()).hexdigest())
        report.save=save
        report.figure_ablation(plt,results['heldout_ablation'],output,results['label'])
        entries,assessment=report.load_assessment(RUN/'heldout')
        example=report.figure_example(plt,RUN,entries,results['primary_candidate']['run'],output,results['label'])
        assert example==results['example_figure'], 'Example selection changed'
        for name in results['figure_evidence']:
            if name not in record['figures']:
                for ext in ('png','svg'): shutil.copyfile(E/'figures'/(name+'.'+ext),output/(name+'.'+ext))
                record['figures'][name]=dict(operation='EXACT_CANONICAL_BYTE_COPY')
            record['figures'][name]['files_sha256']={ext:sha(output/(name+'.'+ext)) for ext in ('png','svg')}
            record['figures'][name]['canonical_files_sha256']=results['figure_evidence'][name]['files_sha256']
        assert len(record['figures'])==5 and not check(); record.update(finished_utc=datetime.now(timezone.utc).isoformat(),changed_protected_files=[],example_selection=example,status='RENDERED_PENDING_VISUAL_QA',no_statistical_or_primary_output_change=True)
        (output/'RENDER_MANIFEST.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n'); fcntl.flock(lock,fcntl.LOCK_UN)
    print(json.dumps(dict(status=record['status'],manifest_sha256=sha(output/'RENDER_MANIFEST.json'))))
if __name__=='__main__': main()
