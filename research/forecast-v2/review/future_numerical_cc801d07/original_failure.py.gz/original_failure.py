"""Pure synthetic reproduction preserved before the future support repair."""
import hashlib, importlib.util, json, sys
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import torch
repo=Path('/Users/jp/Documents/Codex/2026-10-30/work-in-the-wildfireguardian-repository-on/work/track-1b')
sys.path.insert(0,str(repo/'research/forecast-v2/scripts'))
path=Path(__file__).parent/'baseline/blind_test.py'
spec=importlib.util.spec_from_file_location('original_blind_failure',path)
b=importlib.util.module_from_spec(spec);sys.modules[spec.name]=b;spec.loader.exec_module(b)
initial=np.array([[True,False],[False,False]])
sample=SimpleNamespace(initial=initial,score_mask=np.ones((2,2),bool),environment=np.ones((2,2,2)),hours=1,event_id='SYNTHETIC_ONLY')
base=np.full((2,2),.25);valid=~initial
rows=[]
for target in ['c651','structured','logistic']:
 def forecast(model,sample,**kwargs):
  q=base.copy()
  if model==target:q[0,1]=np.nan
  return torch.tensor(q),torch.tensor(valid)
 def logistic(*args):
  q=base.copy()
  if target=='logistic':q[0,1]=np.nan
  return q
 p=SimpleNamespace(sample_forecast=forecast,logistic_predict=logistic,logistic_features=lambda *args:np.ones((4,1)))
 env=SimpleNamespace(names=['a','b'],terrain_gradient=lambda event:np.zeros((2,2)))
 try:
  _,mask=b.deterministic_fields((p,env,SimpleNamespace(predictor='c651'),{'base_seed0':'structured'},None),sample,{'best_dilation_hours_per_cell':4})
  rows.append(dict(target=target,raised=False,admitted_cells=int(mask.sum()),expected_declared_cells=3))
 except ValueError as e:rows.append(dict(target=target,raised=True,error=str(e)))
result=dict(source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),probes=rows,actual_study_data_accessed=False)
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
