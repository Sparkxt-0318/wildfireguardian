"""Authenticate supplied deterministic scenarios, then optionally rescore a subset.

The audit reads identities/references only. Optional scoring requires completed
new assessment entries and recomputes every comparator on identical ordered
cell-interval entries. Historical M548 probabilities are never admitted.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve()
REPO = HERE.parents[3]
sys.path.insert(0, str(REPO / "forecast"))
from wildfire.cumulative_report import case_seed


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--assessment", type=Path)
    args = parser.parse_args()
    catalog = {e["id"]: e for e in json.loads((args.data / "environment/events.json").read_text())}
    extraction = args.data / "FARSITE_INPUTS_EXTRACTION.json"
    inputs = json.loads(extraction.read_text())
    for row in inputs["files"]:
        if not row["historical_input_identity_matches"] or sha(args.data / row["path"]) != row["sha256"]:
            raise ValueError("A historical scenario input identity changed")
    receipts = {}
    if args.assessment:
        assessed = json.loads((args.assessment / "ASSESSMENT.json").read_text())
        if assessed["status"] != "COMPLETE":
            raise ValueError("Complete new US2024 assessment required before matched subset scoring")
        receipts = {(r["case"]["event"], pd.Timestamp(r["case"]["cutoff"]), pd.Timestamp(r["case"]["endpoint"])): r
                    for r in assessed["cases"]}
    rows, entries = [], []
    root = args.data / "historical_observed/20261013_observed_merged/cases"
    for directory in sorted(root.iterdir()):
        report_path = directory / "report.json"
        report = json.loads(report_path.read_text())
        protocol = json.loads((directory / "protocol.json").read_text())
        manifest = json.loads((directory / "combined_case_manifest.json").read_text())
        for name, expected in manifest.items():
            if sha(directory / name) != expected:
                raise ValueError("Historical scenario bytes changed")
        event, start, end = protocol["event"], pd.Timestamp(protocol["cutoff"]), pd.Timestamp(protocol["endpoint"])
        grid = catalog[event]
        context = report["farsite_input_manifest"]
        expected_seed = case_seed(0, event, start.isoformat())
        if (protocol["n_samples"] != 1024 or protocol["case_seed"] != expected_seed
                or protocol["trajectory_batch_size"] != 32 or protocol["boundary"] != "zero"
                or protocol["environment_policy"] != "repeated_current"
                or pd.Timestamp(protocol["environmental_snapshot_time_utc"]) != start.floor("h")
                or abs((end - start).total_seconds() / 3600 - protocol["hours"]) > 1e-9):
            raise ValueError("Historical comparison configuration differs")
        if (context["original_shape"] != [grid["height"], grid["width"]]
                or context["original_epsg"] != grid["epsg"]
                or not np.array_equal(context["original_transform"], grid["transform"])):
            raise ValueError("Historical FARSITE rectangle differs")
        states_path = args.data / "perimeters" / event / "states.npz"
        with np.load(states_path, allow_pickle=False) as source, np.load(directory / "reference.npz", allow_pickle=False) as ref:
            times = list(pd.to_datetime(source["times"], utc=True))
            i, j = times.index(start), times.index(end)
            if j != i + 1 or not np.array_equal(ref["burned_area"][:, 0].astype(bool), source["states"][[i, j]].astype(bool)):
                raise ValueError("Historical initial or endpoint extent differs")
            reference_valid = ref["burned_area_valid"][0, 0] & ref["burned_area_valid"][1, 0] & ref["pixel_valid"][0]
            initial = source["states"][i].astype(bool)
            endpoint = source["states"][j].astype(bool)
        with np.load(directory / "farsite_prediction.npz", allow_pickle=False) as f:
            fp, fv = f["probability"][0, 0].copy(), f["valid"][0, 0].copy()
            metadata = json.loads(str(f["metadata_json"]))
        if not np.isin(fp[fv], (0, 1)).all() or not metadata["observed_initial"]:
            raise ValueError("Expected one deterministic observed-cutoff scenario")
        row = dict(case_id=directory.name, event=event, cutoff=start.isoformat(), endpoint=end.isoformat(),
            status="AUTHENTICATED_IDENTITIES_ONLY", report_sha256=sha(report_path),
            reference_sha256=sha(directory / "reference.npz"), farsite_prediction_sha256=sha(directory / "farsite_prediction.npz"),
            initial_and_endpoint_equal_current_source=True, consecutive_survey_pair=True,
            source_raster_identities_verified=True, weather="same cutoff-source rasters; FARSITE repeats a spatially summarized station scenario",
            boundary="FARSITE one-cell nonburnable fuel99 padding; original rectangle and explicit validity retained",
            native_executable_sha256=report["models"][1]["sha256"], historical_m548_predictions_admitted=False)
        if args.assessment:
            record = receipts[(event, start, end)]
            path = args.assessment / "cases" / f"{record['case_id']}.npz"
            if record["status"] != "SCORED" or sha(path) != record["sha256"]:
                raise ValueError("New assessment case identity changed")
            with np.load(path, allow_pickle=False) as scored:
                rr, cc = scored["row"], scored["col"]
                use = fv[rr, cc] & reference_valid[rr, cc] & ~initial[rr, cc] & np.isfinite(fp[rr, cc])
                if not np.array_equal(scored["y"], endpoint[rr, cc]):
                    raise ValueError("Ordered assessed endpoint cells differ")
                predictions = {n[2:]: scored[n][use].copy() for n in scored.files if n.startswith("p_")}
                predictions["farsite_scenario"] = fp[rr[use], cc[use]]
                entries.append(dict(fire=np.full(int(use.sum()), event), y=scored["y"][use].copy(), predictions=predictions))
                row.update(status="SCORED_COMMON_SUBSET", cells=int(use.sum()),
                           exact_row_col_sha256=hashlib.sha256(np.column_stack((rr[use], cc[use])).tobytes()).hexdigest())
        rows.append(row)
    result = dict(evidence_class="authenticated stored deterministic scenarios; fresh metric recomputation only when assessment supplied",
        source_input_manifest_sha256=sha(extraction), cases=rows,
        coverage="30stored intervals across6US2024fires, incomplete relative to all eligible2024 intervals; no extrapolation",
        native_execution_this_command=False)
    if entries:
        spec = importlib.util.spec_from_file_location("matched_subset_reporting", HERE.with_name("report.py"))
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        combined = dict(fire=np.concatenate([e["fire"] for e in entries]), y=np.concatenate([e["y"] for e in entries]),
            predictions={n: np.concatenate([e["predictions"][n] for e in entries]) for n in entries[0]["predictions"]})
        result["scores"] = module.detailed_scores(combined)
    args.out.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(dict(cases=len(rows), scored="scores" in result)))


if __name__ == "__main__":
    main()
