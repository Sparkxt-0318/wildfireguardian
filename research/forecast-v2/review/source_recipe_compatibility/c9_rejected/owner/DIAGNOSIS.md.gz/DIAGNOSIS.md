# Actual fit-coverage source-recipe refusal

This is a source/phase-metadata diagnosis and a scratch-only proposed guard repair. No raw input arrays, sample caches, checkpoints, heldout quality, training, or Monte Carlo execution were read or run. The original failure JSON/log and original producer bytes remain unchanged.

The original guard refuses 23 of the 28 authenticated intended phases: 18 development phases and five finals. DIAGNOSIS.json lists every phase, exact result/receipt source identity, affected function, and original guard outcome. SOURCE_DELTAS.diff contains every material old/current function AST delta.

| Immutable pipeline source | Affected intended phases | Exact differences |
| --- | --- | --- |
| fe2304501159aa7340f305e8eb7a93e4199c59f9bb100f30667f60daeec00978 | 15 base/d4/d4_wind/ellipse/burnout folds, plus base and d4 finals | New perimeter custody prefix and explicit np.load allow_pickle=False; old mixed-only cache key; missing kriged source check; old unfloored kriged label clock |
| 80a806e1177592fc4c16c12e78090a942b5cd1d985e644513fa8f401b8cf0439 | Three mixed_base UTC-fixed folds, plus d4_wind final | New perimeter custody prefix and kriged _verify_sources check only; UTC label correction already present |
| e59d157a4905fd64fb87499e5664375e2384bcc6ad39f2978812e7f3646deb38 | ellipse and burnout finals | Same custody-check additions only; kriged body unused for these pure variants |

All available and build_model function ASTs are identical. The other five intended phases already pass the original guard: corrected spotting folds/final and the mixed final. There is no docstring-only explanation for the refusal.

The old UTC recipe is a real semantic difference. A synthetic fractional t0 produces two old windows versus one corrected window, with different sample identities. It must never be waived for a mixed fit. Every actual phase using that oldest source is pure, so the immutable fixed VARIANTS table and exact command train/validation call resolve mixed=False and never consume the mixed branch or kriged body. Actual mixed development uses the corrected source.

The proposed guard preserves source hashes and only normalizes the exact known perimeter custody prefix/explicit np.load(False) form and exact kriged source-verification insertion. This is conditional equivalence on independently source/cache-authenticated inputs, schemas and complete values. Custody additions change admission on bad inputs: a separate negative manifest test demonstrates old acceptance and current refusal. It does not claim universal function equivalence or that historical jobs executed the newer checks.

For proven pure variants, only the unused mixed branch and kriged BODY may be excluded from comparison. The unused kriged signature/defaults/decorators/returns/annotations remain identical. Dedicated default-value, default-side-effect, decorator, return and argument-annotation refusals enforce this definition-time boundary. Model/available/global variant table/optimizer/crop/list/interval/budget/skip guards remain. The first3 population and provably nonbinding default160 cap rules are unchanged.

The source/cache membership and value audits remain mandatory before the compatibility proof is consumed by audit_coverage. No caller flag replaces that authentication. All 28 actual immutable source contracts pass in scratch with the proposed guard, but this is not a rerun or pass of real FIT_COVERAGE: later complete membership/count/value gates must still run on the owner's actual authenticated artifacts.

Validation: 18 new focused controls pass; the final bounded suite passes 116 controls with 131 unrelated tests deselected. It retains prior underbudget, partial-population, interval/event, cache-value, old-source, cap, optimizer and unsupported-skip refusals. No full production regression was rerun. Nine immutable producer source identities are preserved as content-addressed gzip source bytes, with decompressed hashes checked.

Do not apply while a06 comparisons consume the fixed 61-file closure. Wait for all 12 cases AND the aggregate/receipt closure, then independently review/apply and perform a fresh actual coverage audit under its normal custody/lease procedure. Preserve the existing failed coverage execution.
