"""Finalize unprotected documentary ledgers from hash-bound saved evidence only."""
from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,shutil
W=Path(__file__).resolve().parent; R=W/'track-1b'; E=R/'research/forecast-v2'; sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
proposal_path=W/'final-forecast-ledger-proposal.json'; assert sha(proposal_path)=='a8fa79c54c078a18ba71df90c487bbe2b0e7b039823af9da95de6e3ff7da4ad2'; proposal=json.loads(proposal_path.read_text())
folder=E/'review/final_delivery'; folder.mkdir(exist_ok=False); pre=folder/'pre_final'; pre.mkdir(); protected=json.loads((E/'executions/current_descriptive_intervals_actual_v2.json').read_text())['protected_files_sha256'];
for prefix in [E/'publication-render',E/'supplements',E/'source_snapshots']:
 for p in prefix.rglob('*'):
  if p.is_file(): protected[str(p.relative_to(R))]=sha(p)
for p in [E/'RESULTS.json',E/'FARSITE_SCORES.json',E/'FIGURE_QA_ORIGINAL.json']: protected[str(p.relative_to(R))]=sha(p)
assert all(sha(R/n)==h for n,h in protected.items()); (folder/'PROTECTED_BEFORE.json').write_text(json.dumps(protected,indent=2,sort_keys=True)+'\n')
archives={}
for name in ['README.md','REQUIREMENTS_STATUS.json','GATE_HISTORY.json']:
 src=E/name; dst=pre/name; shutil.copyfile(src,dst); archives[name]=dict(path=str(dst.relative_to(R)),sha256=sha(dst))
prep=folder/'preparation'; prep.mkdir();
for name in ['final-forecast-ledger-proposal.json','final-forecast-ledger-notes.md','final-report-packaging-checklist.md']: shutil.copyfile(W/name,prep/name)
independent=folder/'independent'; independent.mkdir(); archive_records=[]
def archive(source,relative,expected=None):
 source=Path(source); assert expected is None or sha(source)==expected
 target=independent/relative; raw=source.read_bytes(); original_hash=hashlib.sha256(raw).hexdigest()
 if source.suffix=='.py' or b'\xe2\x80\x94' in raw:
  target=target.with_name(target.name+'.gz'); raw=gzip.compress(raw,mtime=0)
 target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(raw); value=dict(path=str(target.relative_to(R)),sha256=sha(target),original_sha256=original_hash,source=str(source),compressed=target.suffix=='.gz'); archive_records.append(value); return value
interval=W/'descriptive-interval-actual-independent-review'; receipt=json.loads((interval/'INDEPENDENT_REVIEW_RECEIPT.json').read_text())
assert receipt['status']=='PASS_INDEPENDENT_ACTUAL_SAVED_OUTPUT_REVIEW' and receipt['producer_result_sha256']=='060cb9db4ab4918dde57adbff478ae68437de91b0b0efdc0e7cb75ad32e25e5c'
for name,h in receipt['artifacts_sha256'].items(): archive(interval/name,Path('descriptive_intervals')/name,h)
archive(interval/'INDEPENDENT_REVIEW_RECEIPT.json',Path('descriptive_intervals/INDEPENDENT_REVIEW_RECEIPT.json'))
replay=next(v for v in archive_records if v['original_sha256']=='08a19a8811ccbc3fab38bc3cd9348c7d5396f525762453b619aa9000ab247158'); assert not replay['compressed']
far=archive(W/'farsite-actual-independent-review/ACTUAL_REVIEW.json',Path('farsite/ACTUAL_REVIEW.json'),'26c5a52e0eec8a977b947a87a9cf7391243ddc2aeded58bbb173ed965787d2e4')
archive(W/'farsite-actual-independent-review/REVIEW.md',Path('farsite/REVIEW.md'),'945bf3b2e6e31ba98bac5f6f635518898806eec91c1a74e3f14ddfdd35abca80')
pub=archive(W/'PUBLICATION_FIVE_FIGURE_QA_PARENT.json',Path('publication/INDEPENDENT_QA.json'),'405800b248a115e7a80a163bdd5c0d8cf0d1f7fe9c6b583c7af29c605846727d')
(folder/'INDEPENDENT_ARCHIVE_INDEX.json').write_text(json.dumps(dict(artifacts=archive_records,scope='Exact source/review bytes, optionally deterministic gzip; no new numerical review or identity authentication.'),indent=2,sort_keys=True)+'\n')
evidence=proposal['evidence']; evidence['existing_requirements']=archives['REQUIREMENTS_STATUS.json']; evidence['gate_history']=archives['GATE_HISTORY.json']; evidence['checklist']=dict(path=str((prep/'final-report-packaging-checklist.md').relative_to(R)),sha256=sha(prep/'final-report-packaging-checklist.md')); evidence['sidecar_independent_review']={k:replay[k] for k in ('path','sha256')}; evidence['publication_independent_review']={k:pub[k] for k in ('path','sha256')}; evidence['FARSITE_independent_review']={k:far[k] for k in ('path','sha256')}
for key,path in [('preregistration','forecast/documents/preregistration_blind_test.md'),('registry','research/forecast-v2/BLIND_REGISTRY.json'),('selection','research/forecast-v2/MODEL_SELECTION.json'),('freeze_handoff','research/forecast-v2/FREEZE_HANDOFF.json')]: evidence[key]=dict(path=path,sha256=sha(R/path))
ledger=json.loads((pre/'REQUIREMENTS_STATUS.json').read_text()); patches={p['id']:p for p in proposal['requirement_patches']}; assert len(patches)==125 and {x['id'] for x in ledger['requirements']}==set(patches)
for row in ledger['requirements']:
 patch=patches[row['id']]; assert row['status']==patch['old_status']; row['previous_documentary_status']=row['status']; row['previous_evidence']=row.get('evidence'); row.update(patch['proposed_fields'])
 if row['id']=='1B-5-pre-registration': row['evidence']=['preregistration','registry','selection','freeze_handoff']
 if row['id'].startswith('fig'):
  row['publication_independent_qa']='PASS_SCOPED_VISUAL_REVIEW'; row['publication_independent_qa_evidence']='publication_independent_review'
ledger.update(final_extension_schema='wfg.forecast-v2.final-documentary-overlay/1',finalized_utc=datetime.now(timezone.utc).isoformat(),evidence_class='REAL_CURRENT_ASSESSMENT_WITH_QUALIFIED_SAVED_OUTPUT_REPLAYS',evidence_registry=evidence,final_state_axes=proposal['state_axes'],publication_evidence=proposal['publication_evidence_extension'],descriptive_interval_supplement=proposal['sidecar'],primary_superiority_criteria_pass=False,promotion_authority=False,prior_ledger=archives['REQUIREMENTS_STATUS.json'],documentary_provenance=dict(source_proposal_sha256=sha(proposal_path),status_source_sha256=sha(E/'scripts/status.py'),base_generator_rerun=False,reason='Preserve frozen canonical outputs and separately qualify publication/interval evidence; unchanged base generator does not represent those separate identities.'))
ledger['committed_freeze_verification']=dict(status='PASS_BEFORE_ORIGINAL_INFERENCE',freeze_commit='6887dc618253e6568c6cbbfd3c9a96f1d0d86b70',evidence=dict(path='research/forecast-v2/supplements/current_descriptive_intervals_v2/evidence/FREEZE_PARENT_VERIFICATION.json',sha256='1e9def628deb2e7f1035aea691c39f8acf27f606bcdccffd0e6d3dff4f344db6'))
ledger['final_state_axes']['publication_visual_qa']='PASS_OWNER_AND_INDEPENDENT_SET_PRESERVE_ORIGINAL_CANONICAL_HOLD'; ledger['baseline_aliases']=proposal['baseline_aliases']; ledger['delivery_limits']=['Current primary superiority criterion is false.','Korean complete-cohort intervals remain unavailable; all seven original outcomes retained.','FARSITE is a separate stored29-scenario matched subset, not full273 population.','Original two canonical layout clippings remain beside the separately reviewed publication set.','2026 execution/OSF/publisher chronology and documentary clearance remain external, not actual study completion claims.']
(E/'REQUIREMENTS_STATUS.json').write_text(json.dumps(ledger,indent=2,sort_keys=True,allow_nan=False)+'\n')
gate=json.loads((pre/'GATE_HISTORY.json').read_text()); gate['previous_selection_registry_heldout']=gate['selection_registry_heldout']; gate['selection_registry_heldout']='FROZEN_CURRENT_ASSESSMENTS_EXECUTED_US_COMPLETE_KR_SUPPORT_HOLD'; extension=proposal['gate_history_extension']; extension['sidecar_replay_receipt']={k:replay[k] for k in ('path','sha256')}; gate['final_resolution']=dict(recorded_utc=datetime.now(timezone.utc).isoformat(),prior_gate_history=archives['GATE_HISTORY.json'],state_axes=ledger['final_state_axes'],evidence=evidence,history_extension=extension,primary_superiority_criteria_pass=False,failed_supplement_attempt=dict(receipt='research/forecast-v2/executions/current_descriptive_intervals_actual_v1.json',sha256='37f6078bb8adca3933039c1b83e0be4885ca1f05b514f1a5413a57aacbf9219f',interpretation='Missing inventory declarations refused before output or array decode; preserved8b5 authorization. Later attempt uses separately issued3195 authorization/newoutput.'),successful_supplement_attempt=dict(receipt='research/forecast-v2/executions/current_descriptive_intervals_actual_v2.json',sha256='48ba1ed559072f8ccb03f9948951307d6c571b977a89c222c92fe20be06ab8d6',independent_replay={k:replay[k] for k in ('path','sha256')}),physical_validation='NOT_ESTABLISHED',default_promotion=False)
(E/'GATE_HISTORY.json').write_text(json.dumps(gate,indent=2,sort_keys=True,allow_nan=False)+'\n')
readme=(W/'forecast-readme-final-draft.md').read_text(); assert '\u2014' not in readme; (E/'README.md').write_text(readme)
assert all(sha(R/n)==h for n,h in protected.items()); (folder/'FINALIZATION_RECEIPT.json').write_text(json.dumps(dict(schema='wfg.final-documentary-update/1',source_sha256=sha(__file__),protected_files=len(protected),changed_protected_files=[],updated_metadata_sha256={str((E/n).relative_to(R)):sha(E/n) for n in ['README.md','REQUIREMENTS_STATUS.json','GATE_HISTORY.json']},requirements=125,primary_criteria_pass=False,actual_interval_replay={k:replay[k] for k in ('path','sha256')},scope='Metadata/narrative overlay only; no model inference, scoring, source/selection/registry/protocol/canonical figure or metric change.'),indent=2,sort_keys=True)+'\n')
(folder/'finalize-forecast-metadata.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0)); print(json.dumps(dict(status='DOCUMENTARY_UPDATE_COMPLETE',requirements=125,protected_unchanged=len(protected),primary_criteria_pass=False,readme_sha256=sha(E/'README.md'))))
