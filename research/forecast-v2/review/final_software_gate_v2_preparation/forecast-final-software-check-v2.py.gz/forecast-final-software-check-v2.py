from pathlib import Path
import fcntl,hashlib,json,os,platform,subprocess,sys,time
from datetime import datetime,timezone

ROOT=Path('/Users/jp/Documents/Codex/2026-10-30/work-in-the-wildfireguardian-repository-on/work/track-1b')
E=ROOT/'research/forecast-v2/executions'
OUT=E/'final_software_gate_v2.json'
assert not OUT.exists(), 'Preserve existing final gate receipt'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
assert sha(ROOT/'research/forecast-v2/scripts/audit_fit_coverage.py') == '65a7917868b70e00881722bda8ab2af71688fe78bf88128fad0376537f1d6536', 'Live reviewed F65 bytes required'
assert (E/'a06_compare.json').is_file(), 'All12 comparison aggregate receipt must close first'
record=dict(schema='wfg.final-forecast-software-gate/1',pid=os.getpid(),queued_utc=now(),status='WAITING_FOR_SHARED_LEASE',host=dict(platform=platform.platform(),python=platform.python_version(),interpreter=sys.executable,cpu_count=os.cpu_count()))
print(json.dumps(record),flush=True)
with Path('/tmp/wfg/HEAVY.lock').open('a+') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 record.update(acquired_utc=now(),status='RUNNING')
 print(json.dumps(dict(acquired_utc=record['acquired_utc'],pid=os.getpid())),flush=True)
 sources=sorted({p for folder in [ROOT/'forecast/wildfire',ROOT/'forecast/tests',ROOT/'research/forecast-v2/scripts'] for p in folder.rglob('*') if p.is_file() and p.suffix in ('.py','.json') and '__pycache__' not in p.parts}|{ROOT/'forecast/pyproject.toml'})
 record['source_sha256']={str(p.relative_to(ROOT)):sha(p) for p in sources}
 env=dict(os.environ,PYTHONPATH=str(ROOT/'forecast'),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2')
 record['checks']=[]
 for label,cmd in [('pytest',[sys.executable,'-m','pytest','-q','forecast/tests']),('release',[sys.executable,'tools/verify_release.py'])]:
  path=E/('final_software_gate_v2.'+label+'.log')
  assert not path.exists(), 'Preserve existing gate log'
  begin=time.perf_counter()
  with path.open('w') as output:
   result=subprocess.run(cmd,cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT)
  item=dict(name=label,command=cmd,exit_code=result.returncode,elapsed_seconds=time.perf_counter()-begin,log=str(path.relative_to(ROOT)),log_sha256=sha(path))
  record['checks'].append(item)
  print(json.dumps(item),flush=True)
 protected=subprocess.check_output(['git','diff','--name-only','59f3187d70b612bb00b191afa00954ad4b8356a2','--','forecast/wildfire/rollout.py','integration'],cwd=ROOT).decode().splitlines()
 record['protected_path_changes']=protected
 sys.path.insert(0,str(ROOT/'research/forecast-v2/scripts'))
 import pipeline as P
 record['c651_sha256']=sha(P.C651)
 record['c651_matches_frozen_default']=record['c651_sha256']==P.C651_SHA256
 record['changed_source_during_gate']=[p for p,h in record['source_sha256'].items() if sha(ROOT/p)!=h]
 record.update(finished_utc=now(),status='PASS' if all(c['exit_code']==0 for c in record['checks']) and not protected and record['c651_matches_frozen_default'] and not record['changed_source_during_gate'] else 'HOLD')
 OUT.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
 fcntl.flock(lock,fcntl.LOCK_UN)
print(json.dumps(dict(status=record['status'],receipt=str(OUT),receipt_sha256=sha(OUT))),flush=True)
raise SystemExit(0 if record['status']=='PASS' else 1)
