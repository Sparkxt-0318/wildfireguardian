from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,platform,subprocess,sys,time
ROOT=Path('/Users/jp/Documents/Codex/2026-10-30/work-in-the-wildfireguardian-repository-on/work/track-1b')
TASK=ROOT.parent
DATA=TASK/'data/forecast-v2'
E=ROOT/'research/forecast-v2'
OUT=E/'FIT_COVERAGE.json'
RECEIPT=E/'executions/final_fit_coverage_audit_v2.json'
LOG=E/'executions/final_fit_coverage_audit_v2.log'
now=lambda:datetime.now(timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not any(p.exists() for p in (OUT,RECEIPT,LOG)), 'Preserve prior audit artifacts'
assert sha(E/'scripts/audit_fit_coverage.py') == '65a7917868b70e00881722bda8ab2af71688fe78bf88128fad0376537f1d6536', 'Live reviewed F65 bytes required'
assert (E/'executions/a06_compare.json').is_file(), 'Comparison aggregate receipt must close first'
record=dict(pid=os.getpid(),queued_utc=now(),status='WAITING_FOR_FINAL_SOFTWARE_GATE')
print(json.dumps(record),flush=True)
gate=E/'executions/final_software_gate_v2.json'
while not gate.is_file():time.sleep(2)
assert json.loads(gate.read_text())['status']=='PASS', 'Final software gate must pass first'
record['software_gate_sha256']=sha(gate)
record['software_gate_source_sha256']=json.loads(gate.read_text())['source_sha256']
assert all(sha(ROOT/name)==digest for name,digest in record['software_gate_source_sha256'].items()), 'Gate source changed before canonical audit'
print('waiting for shared audit lease',flush=True)
with Path('/tmp/wfg/HEAVY.lock').open('a+') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 record.update(acquired_utc=now(),status='RUNNING')
 print(json.dumps(dict(acquired_utc=record['acquired_utc'],pid=os.getpid())),flush=True)
 paths=[ROOT/'research/forecast-v2/scripts/audit_fit_coverage.py',ROOT/'research/forecast-v2/scripts/pipeline.py',ROOT/'forecast/wildfire/survival.py']
 record['source_sha256']={str(p.relative_to(ROOT)):sha(p) for p in paths}
 cmd=[sys.executable,str(E/'scripts/audit_fit_coverage.py'),'--model-root',str(ROOT),'--input-root',str(DATA),'--cache-root',str(DATA/'campaign-work'),'--run-root',str(ROOT/'forecast/runs/20261030_perimeter_trained/execution_v3'),'--cache-audit',str(E/'CACHE_AUDIT_FINAL.json'),'--out',str(OUT)]
 record['command']=cmd
 begin=time.perf_counter()
 with LOG.open('w') as output:
  result=subprocess.run(cmd,cwd=ROOT,env=dict(os.environ,PYTHONPATH=str(ROOT/'forecast'),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2'),stdout=output,stderr=subprocess.STDOUT)
 record.update(exit_code=result.returncode,elapsed_seconds=time.perf_counter()-begin,finished_utc=now(),log_sha256=sha(LOG),output_sha256=sha(OUT) if OUT.exists() else None,changed_source=[p for p,h in record['source_sha256'].items() if sha(ROOT/p)!=h])
 record['changed_gate_source']=[name for name,digest in record['software_gate_source_sha256'].items() if sha(ROOT/name)!=digest]
 record['status']='PASS' if result.returncode==0 and OUT.is_file() and not record['changed_source'] and not record['changed_gate_source'] else 'HOLD'
 RECEIPT.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
 fcntl.flock(lock,fcntl.LOCK_UN)
print(json.dumps(record),flush=True)
raise SystemExit(0 if record['status']=='PASS' else 1)
