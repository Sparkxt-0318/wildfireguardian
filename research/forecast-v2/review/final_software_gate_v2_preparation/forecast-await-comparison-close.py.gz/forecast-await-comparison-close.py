from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,time
ROOT=Path('/Users/jp/Documents/Codex/2026-10-30/work-in-the-wildfireguardian-repository-on/work/track-1b')
E=ROOT/'research/forecast-v2'
RUN=ROOT/'forecast/runs/20261030_perimeter_trained/execution_v3'
OUT=E/'review/comparison_a06_closure.json'
assert not OUT.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
source=json.loads((E/'executions/a06_compare_case00.json').read_text())['source_sha256']
before={name:sha(ROOT/name) for name in source}
assert before==source and len(source)==61
record=dict(schema='wfg.comparison-source-phase-closure/1',controller_pid=46464,watcher_pid=os.getpid(),started_utc=now(),source_before_sha256=before,watcher_sha256=sha(__file__))
print(json.dumps(dict(status='WAITING_FOR_ALL12_AGGREGATE_RECEIPT_AND_CONTROLLER_EXIT',started_utc=record['started_utc'])),flush=True)
aggregate=E/'executions/a06_compare.json'
while not aggregate.exists():time.sleep(2)
while True:
 try:os.kill(46464,0)
 except ProcessLookupError:break
 # The known process must disappear after writing its closed aggregate.
 time.sleep(1)
agg=json.loads(aggregate.read_text())
assert agg['exit_code']==0 and agg['source_sha256']==source
assert sha(Path(agg['output']))==agg['output_sha256']
rows=json.loads(Path(agg['output']).read_text())
assert len(rows['rows'])==66 and len(rows['case_receipts'])==12
receipts=[]
for index in range(12):
 rp=E/f'executions/a06_compare_case{index:02d}.json'
 rec=json.loads(rp.read_text());output=Path(rec['output']);log=rp.with_suffix('.log')
 assert rec['exit_code']==0 and rec['source_sha256']==source
 assert sha(output)==rec['output_sha256'] and sha(log)==rec['log_sha256']
 expected=dict(path=str(rp.relative_to(ROOT)),sha256=sha(rp))
 assert agg['case_receipts'][index]==expected==rows['case_receipts'][index]
 receipts.append(dict(**expected,output_sha256=rec['output_sha256'],log_sha256=rec['log_sha256'],elapsed_seconds=rec['elapsed_seconds']))
after={name:sha(ROOT/name) for name in source}
assert after==before
record.update(status='CLOSED_ALL12_66ROWS_UNCHANGED61',finished_utc=now(),source_after_sha256=after,changed_sources=[],case_receipts=receipts,aggregate_receipt_sha256=sha(aggregate),aggregate_output_sha256=agg['output_sha256'],controller_exited=True,rows=66,comparison_checkpoint_sha256=rows['checkpoint_sha256'])
assert record['comparison_checkpoint_sha256']=='c651f6724fe6b036b0162edf264cb0063c061b80c2c936d48965ee66afbd1843'
OUT.parent.mkdir(exist_ok=True)
OUT.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(status=record['status'],receipt=str(OUT),sha256=sha(OUT))),flush=True)
