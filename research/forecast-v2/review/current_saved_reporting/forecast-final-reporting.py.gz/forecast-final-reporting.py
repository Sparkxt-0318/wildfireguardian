from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,subprocess,sys,time
root=Path('/Users/jp/Documents/Codex/2026-10-30/work-in-the-wildfireguardian-repository-on/work/track-1b'); e=root/'research/forecast-v2'; run=root/'forecast/runs/20261030_perimeter_trained/execution_v3'; data=root.parent/'data/forecast-v2'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); now=lambda:datetime.now(timezone.utc).isoformat()
u=json.loads((root.parent/'FREEZE_PARENT_VERIFICATION.json').read_text())['verified_file_sha256']; custody=e/'executions/current_assessment_closed_custody.json'; assert sha(custody)=='013eb87e2228eac06085c94ae77c4256b03149db662589486223a44c4f00ccb0'; artifacts=json.loads(custody.read_text())['artifacts_sha256']
check=lambda: [p for p,v in dict(u,**artifacts).items() if sha(root/p)!=v]
assert not check(); assert not(e/'FARSITE_SCORES.json').exists() and not(e/'RESULTS.json').exists()
jobs=[('final_farsite_saved_scenarios',[sys.executable,str(e/'scripts/audit_farsite.py'),'--data',str(data),'--assessment',str(run/'heldout'),'--out',str(e/'FARSITE_SCORES.json')]),('final_canonical_report',[sys.executable,str(e/'scripts/report.py'),'--run',str(run),'--out',str(e)])]
for name,cmd in jobs:
 receipt=e/'executions'/(name+'.json'); log=receipt.with_suffix('.log'); assert not receipt.exists() and not log.exists(); assert not check()
 record=dict(schema='wfg.current-saved-output-execution/1',command=cmd,driver_sha256=sha(__file__),created_utc=now(),frozen_files_sha256=u,canonical_artifacts_sha256=artifacts,pid=os.getpid(),scope='Stored-array postprocessing only; no fitting, model inference, native execution, selection or primary-rule change')
 with open('/tmp/wfg/HEAVY.lock','a+') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX); record['lease_acquired_utc']=now(); assert not check(); record['started_utc']=now(); start=time.perf_counter()
  with log.open('x') as output: result=subprocess.run(cmd,cwd=root,env=dict(os.environ,PYTHONPATH=str(root/'forecast'),PYTHONDONTWRITEBYTECODE='1',MPLBACKEND='Agg',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2'),stdout=output,stderr=subprocess.STDOUT)
  record.update(finished_utc=now(),elapsed_seconds=time.perf_counter()-start,exit_code=result.returncode,changed_protected_files=check(),log=str(log.relative_to(root)),log_sha256=sha(log)); record['lease_released_utc']=now(); fcntl.flock(lock,fcntl.LOCK_UN)
 record['status']='COMPLETE_COMMAND' if result.returncode==0 and not record['changed_protected_files'] else 'FAILED_COMMAND_OR_CUSTODY'; receipt.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n'); print(json.dumps(dict(job=name,status=record['status'],exit_code=result.returncode,receipt_sha256=sha(receipt))),flush=True)
 if result.returncode or record['changed_protected_files']: raise SystemExit(result.returncode or 1)
