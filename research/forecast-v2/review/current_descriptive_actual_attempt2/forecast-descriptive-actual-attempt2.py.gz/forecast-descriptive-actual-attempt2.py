from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,importlib.metadata,json,os,platform,shutil,subprocess,sys,time
W=Path(__file__).resolve().parent; R=W/'track-1b'; E=R/'research/forecast-v2'; bundle=E/'supplements/current_descriptive_intervals_v2'; tool=bundle/'tool/supplement.py'; source_auth=W/'DESCRIPTIVE_INTERVAL_ACTUAL_AUTHORIZATION_ATTEMPT2.json'; expected='3195c8c789954f845622e35f7fbe43d792bfa8a432700507fea4c6df7d195ebc'; sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); now=lambda:datetime.now(timezone.utc).isoformat()
assert sha(source_auth)==expected and sha(tool)=='c41e607a167edae4058da2d5945c30b3d6e021f79461b17cdabf07c442bca799'
a=json.loads(source_auth.read_text()); assert a['status']=='AUTHORIZED_SAVED_OUTPUT_ONLY'; auth=bundle/'evidence/ACTUAL_AUTHORIZATION_ATTEMPT2.json'; assert not auth.exists(); shutil.copyfile(source_auth,auth); assert sha(auth)==expected
protected=json.loads((W/'publication-render-core-protection-derived.json').read_text()); assert len(protected)==858; protected.update(a['input_artifacts_sha256']); protected[str(auth.relative_to(R))]=expected
m=json.loads((bundle/'tool/CANDIDATE_MANIFEST.json').read_text())
for n,v in m['files'].items(): protected[str((bundle/'tool'/n).relative_to(R))]=v['sha256']
check=lambda:[n for n,h in protected.items() if sha(R/n)!=h]
assert not check(); out=R/a['output_relative_directory']; assert not out.exists(); receipt=E/'executions/current_descriptive_intervals_actual_v2.json'; log=receipt.with_suffix('.log'); assert not receipt.exists() and not log.exists()
command=[sys.executable,str(tool),'--protocol',str(bundle/'tool/method/DESCRIPTIVE_INTERVAL_PROTOCOL_V1.json'),'--model-root',str(R),'--run',str(R/a['run_relative_path']),'--results',str(E/'RESULTS.json'),'--authorization',str(auth),'--authorization-sha256',expected,'--out',str(out)]
record=dict(schema='wfg.current-descriptive-interval-execution/1',started_utc=now(),command=command,driver_sha256=sha(__file__),executing_source_sha256=sha(tool),authorization_sha256=expected,root_metadata_preflight_sha256=sha(W/'DESCRIPTIVE_INTERVAL_METADATA_PREFLIGHT_ATTEMPT2.json'),protected_files_sha256=protected,host=dict(platform=platform.platform(),python=platform.python_version(),cpu_count=os.cpu_count(),interpreter=sys.executable),dependencies={k:importlib.metadata.version(k) for k in ('numpy','scipy','scikit-learn')},lease_scope='Exact c41 code acquires shared HEAVY internally. External observations below are not kernel acquisition timestamps.',model_handling='Frozen checkpoint/source custody uses raw byte SHA256 checks only; no model deserialization or inference.')
start=time.perf_counter(); held=None; first_output=None
with log.open('x') as output:
 p=subprocess.Popen(command,cwd=R,env=dict(os.environ,PYTHONPATH=str(R/'forecast'),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2'),stdout=output,stderr=subprocess.STDOUT); record['child_pid']=p.pid
 while p.poll() is None:
  if out.exists() and first_output is None: first_output=now()
  if out.exists() and held is None:
   with open('/tmp/wfg/HEAVY.lock','a+') as probe:
    try: fcntl.flock(probe,fcntl.LOCK_EX|fcntl.LOCK_NB); fcntl.flock(probe,fcntl.LOCK_UN)
    except BlockingIOError: held=now()
  time.sleep(.25)
 changed=check(); record.update(finished_utc=now(),elapsed_seconds=time.perf_counter()-start,exit_code=p.returncode,external_lock_held_observed_utc=held,exclusive_output_first_observed_utc=first_output,changed_protected_files=changed,log_sha256=sha(log),output_artifacts_sha256={str(q.relative_to(R)):sha(q) for q in out.rglob('*') if q.is_file()} if out.exists() else {},status='COMPLETED_COMMAND' if p.returncode==0 and not changed else 'FAILED_COMMAND_OR_CUSTODY')
receipt.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n'); print(json.dumps({k:record[k] for k in ('status','exit_code','child_pid','changed_protected_files','external_lock_held_observed_utc')})); print(json.dumps(dict(receipt_sha256=sha(receipt),output_artifacts=record['output_artifacts_sha256']))); raise SystemExit(p.returncode or bool(changed))
