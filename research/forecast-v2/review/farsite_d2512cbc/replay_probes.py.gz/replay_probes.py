"""Replay both preserved independent synthetic payloads without overwriting originals."""
import hashlib, json
from pathlib import Path
work=Path(__file__).parent
replay=work/'replay';replay.mkdir(exist_ok=True)
results={}
for name in ['probe_missing_model.py','probe_long_interval.py']:
 original=work/'original'/name
 source=original.read_text()
 adapted=source.replace("work/audit-1b", "work/track-1b").replace('farsite-subset-review-6ae52ab2','farsite-model-set-repair/replay')
 target=replay/name;target.write_text(adapted)
 record=dict(original_source_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),adapted_source_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
             adaptation='fixture repository root and evidence output root only; synthetic mutation payload unchanged')
 try:
  exec(compile(adapted,str(target),'exec'),{'__name__':'__main__','__file__':str(target)})
  assert name=='probe_long_interval.py'
  observed=json.loads((replay/'long_interval_probe.json').read_text())
  assert observed['accepted_status']=='HOLD' and observed['scores_available'] is False and observed['row_status']=='UNAVAILABLE'
  assert observed['native_horizon']['status']=='AVAILABLE'
  record.update(refused_scoring=True,observed=observed)
 except ValueError as error:
  assert name=='probe_missing_model.py' and 'fixed 16 probability columns' in str(error)
  record.update(refused_scoring=True,error_type=type(error).__name__,reason=str(error))
 results[name]=record
(work/'REPLAY_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
