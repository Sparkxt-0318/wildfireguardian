"""Inner canonical-file custody checks, not the pending root-permission adapter.

The expectations below must originate from future independently authenticated
root/census/review receipts. No CLI currently constructs them from caller data.
Invented tests seal them before mutation. They cannot by themselves attest the
missing external prerequisite schema or authorize actual artifact access.
"""
from __future__ import annotations

from dataclasses import dataclass
import io
from pathlib import Path

import numpy as np

import supplement as S


@dataclass(frozen=True)
class Artifact:
    path: Path
    sha256: str


@dataclass(frozen=True)
class ExpectedCase:
    case_id: str
    identity: dict
    source_fields: dict
    receipt: Artifact
    entries: Artifact | None
    rows_sha256: str | None
    cols_sha256: str | None
    labels_sha256: str | None
    mask_sha256: str
    cells: int
    positives: int | None


@dataclass(frozen=True)
class CohortExpectation:
    cohort: str
    directory: Path
    assessment: Artifact
    frozen: Artifact
    canonical_report: Artifact
    cases: tuple[ExpectedCase, ...]
    per_fire: dict[str, Artifact]
    source_artifacts: tuple[Artifact, ...]
    input_artifacts: tuple[Artifact, ...]
    prerequisite_artifacts: tuple[Artifact, ...]
    expected_source_map_sha256: str
    expected_input_map_sha256: str
    expected_prerequisite_map_sha256: str


class Files:
    def __init__(self):
        self.seen = {}

    def read(self, artifact):
        path = Path(artifact.path)
        if not path.is_absolute() or any(part.is_symlink() for part in (path, *path.parents)):
            raise S.AdmissionError("Pinned artifact must be an explicit regular nonsymlink path")
        if not path.is_file():
            raise S.AdmissionError("Missing required canonical artifact")
        data = path.read_bytes()
        if S.sha_bytes(data) != artifact.sha256:
            raise S.AdmissionError("Canonical consumed artifact bytes changed")
        if str(path) in self.seen and self.seen[str(path)] != artifact.sha256:
            raise S.AdmissionError("One canonical path has conflicting identities")
        self.seen[str(path)] = artifact.sha256
        return data

    def json(self, artifact):
        return S.strict_json(self.read(artifact))

    def npz(self, artifact):
        return np.load(io.BytesIO(self.read(artifact)), allow_pickle=False)

    def unchanged(self):
        for path, expected in self.seen.items():
            self.read(Artifact(Path(path), expected))
        return dict(self.seen)


SOURCE_FIELDS = {"initial_sha256", "endpoint_sha256", "environmental_snapshot_sha256",
    "reference_mask_sha256", "initial_age_sha256", "residence_sha256", "rectangle", "reference_cells", "weather_hour"}


def identity_map(artifacts):
    result = {}
    for artifact in artifacts:
        key = str(artifact.path)
        if key in result:
            raise S.AdmissionError("Duplicate artifact in sealed custody expectation")
        result[key] = artifact.sha256
    return result


def check_bindings(files, expected):
    for artifacts, digest in ((expected.source_artifacts, expected.expected_source_map_sha256),
                              (expected.input_artifacts, expected.expected_input_map_sha256),
                              (expected.prerequisite_artifacts, expected.expected_prerequisite_map_sha256)):
        mapping = identity_map(artifacts)
        if not mapping or S.object_sha(mapping) != digest:
            raise S.AdmissionError("Missing/extra source, input or independent-review binding")
        for artifact in artifacts:
            files.read(artifact)


def checked_case(files, expected, record, frozen_sha, models):
    if (record.get("receipt_version") != "wfg.forecast-assessment-case/2"
            or record.get("case_id") != expected.case_id or record.get("case") != expected.identity
            or record.get("assessment_sha256") != frozen_sha
            or set(expected.source_fields) != SOURCE_FIELDS
            or any(record.get(name) != value for name, value in expected.source_fields.items())
            or files.json(expected.receipt) != record):
        raise S.AdmissionError("Individual case, source identity or frozen receipt mismatch")
    if record.get("status") != "SCORED":
        if record.get("status") not in ("UNAVAILABLE", "FAILED") or not record.get("reason") or expected.entries is not None:
            raise S.AdmissionError("Unavailable canonical case requires its original outcome/reason and no prediction")
        return None
    if expected.entries is None or record.get("sha256") != expected.entries.sha256:
        raise S.AdmissionError("Missing exact individual prediction binding")
    with files.npz(expected.entries) as data:
        if set(data.files) != {"row", "col", "y", *("p_"+name for name in models)}:
            raise S.AdmissionError("Every case must contain all and only the16 fixed probability columns")
        row, col, y = data["row"], data["col"], data["y"]
        shape = expected.source_fields["rectangle"]
        if (not isinstance(shape, list) or len(shape) != 2 or any(type(n) is not int or n <= 0 for n in shape)
                or row.dtype.kind not in "iu" or col.dtype.kind not in "iu" or row.ndim != 1 or col.shape != row.shape
                or y.shape != row.shape or not len(y) or not np.isin(y, (0, 1)).all()
                or (row < 0).any() or (col < 0).any() or (row >= shape[0]).any() or (col >= shape[1]).any()
                or (np.diff(row.astype(np.int64)*shape[1] + col.astype(np.int64)) <= 0).any()):
            raise S.AdmissionError("Case coordinates must be complete ordered integer source cells with binary labels")
        mask = np.zeros(shape, bool); mask[row, col] = True
        if (S.array_sha(row) != expected.rows_sha256 or S.array_sha(col) != expected.cols_sha256
                or S.array_sha(y) != expected.labels_sha256 or S.array_sha(mask) != expected.mask_sha256
                or record.get("scored_mask_sha256") != expected.mask_sha256
                or type(expected.cells) is not int or expected.cells <= 0 or len(y) != expected.cells
                or record.get("scored_cells") != expected.cells or int(y.sum()) != expected.positives
                or record.get("positives") != expected.positives):
            raise S.AdmissionError("Full expected support, ordered labels or case counts changed")
        for name in models:
            p = data["p_"+name]
            if p.dtype.kind not in "iuf" or p.shape != y.shape or not np.isfinite(p).all() or ((p < 0) | (p > 1)).any():
                raise S.AdmissionError("Invalid common-population probability cannot become an exclusion")
        return dict(row=row.copy(), col=col.copy(), y=y.copy())


@dataclass
class CanonicalCohort:
    expected: CohortExpectation
    files: Files
    labels: list[np.ndarray]
    points: dict
    per_fire_counts: list[int]

    def model(self, name):
        if name not in S.protocol()["model_order"]:
            raise S.AdmissionError("Caller-selected model cannot enter the fixed cohort")
        values = []
        for event in S.protocol()["cohorts"][self.expected.cohort]["fire_order"]:
            with self.files.npz(self.expected.per_fire[event]) as aggregate:
                values.append(aggregate["p_"+name].astype(np.float64))
        return values

    def after(self):
        return self.files.unchanged()


def verify_cohort(expected):
    """Strict inner join against sealed expectations; no available-fire fallback.

    Returns a null-cohort descriptor for honest unavailable canonical support.
    Missing/corrupt/unlisted data raise AdmissionError. Root prerequisite receipt
    authentication is intentionally a separate pending outer boundary.
    """
    method = S.protocol()
    if expected.cohort not in method["cohorts"]:
        raise S.AdmissionError("Unknown cohort")
    spec = method["cohorts"][expected.cohort]
    models = method["model_order"]
    files = Files(); check_bindings(files, expected)
    assessment, frozen, report = files.json(expected.assessment), files.json(expected.frozen), files.json(expected.canonical_report)
    records = assessment.get("cases", [])
    ids = [case.case_id for case in expected.cases]
    if (len(expected.cases) != spec["expected_cases"] or len(set(ids)) != len(ids)
            or [record.get("case_id") for record in records] != ids
            or assessment.get("receipt_version") != "wfg.forecast-assessment/2"
            or assessment.get("frozen_sha256") != expected.frozen.sha256
            or set(assessment.get("events", [])) != set(spec["fire_order"])
            or len(assessment.get("events", [])) != len(spec["fire_order"])
            or frozen.get("cohort") != expected.cohort
            or report.get("model_selection_sha256") != frozen.get("selection_sha256")
            or not frozen.get("selection_sha256") or report.get("current_phase") != frozen.get("current_phase")):
        raise S.AdmissionError("Complete fixed case/fire population or canonical frozen source/selection differs")
    report_key = "heldout" if expected.cohort == "us2024" else "korean2025_secondary_reconstruction"
    canonical = report.get(report_key, {})
    if canonical.get("assessment_status") != assessment.get("status"):
        raise S.AdmissionError("Canonical report and assessment status differ")
    directory = Path(expected.directory)
    actual_case_json = {p.resolve() for p in (directory/"cases").glob("*.json")}
    if actual_case_json != {Path(case.receipt.path).resolve() for case in expected.cases}:
        raise S.AdmissionError("Missing/extra canonical case receipts")
    actual_case_npz = {p.resolve() for p in (directory/"cases").glob("*.npz")}
    if actual_case_npz != {Path(case.entries.path).resolve() for case in expected.cases if case.entries is not None}:
        raise S.AdmissionError("Missing/extra canonical case predictions")
    blocks, outcomes = {}, []
    for wanted, record in zip(expected.cases, records):
        identity = wanted.identity
        import json
        cid = S.sha_bytes(json.dumps(identity, sort_keys=True).encode())[:24]
        if cid != wanted.case_id or set(identity) != {"event", "cutoff", "endpoint", "hours"} or identity["event"] not in spec["fire_order"]:
            raise S.AdmissionError("Case membership/identity differs from sealed complete inventory")
        arrays = checked_case(files, wanted, record, expected.frozen.sha256, models)
        blocks.setdefault(identity["event"], []).append((wanted, record, arrays))
        if arrays is None:
            outcomes.append(record)
    if set(blocks) != set(spec["fire_order"]):
        raise S.AdmissionError("Every fixed fire must have its expected nonempty case inventory")
    if assessment.get("status") != "COMPLETE" or outcomes or assessment.get("failed_or_unavailable"):
        if assessment.get("status") != "HOLD" or not assessment.get("failed_or_unavailable"):
            raise S.AdmissionError("Incomplete canonical support must remain an explicit HOLD with original reasons")
        return dict(cohort=expected.cohort, status="UNAVAILABLE_COMPLETE_CANONICAL_SUPPORT", complete_cohort=False,
                    metrics=None, original_outcomes=assessment["failed_or_unavailable"], promotion_criteria_pass=False,
                    artifact_hashes=files.unchanged(), execution_status=S.EXECUTION_STATUS)
    if (set(expected.per_fire) != set(spec["fire_order"])
            or assessment.get("per_fire_files") != {Path(pin.path).name: pin.sha256 for pin in expected.per_fire.values()}
            or {p.resolve() for p in directory.glob("*.npz")} != {Path(pin.path).resolve() for pin in expected.per_fire.values()}
            or set(canonical.get("models", {})) != set(models)):
        raise S.AdmissionError("All16 fixed models and exact complete per-fire aggregates are required")
    labels, totals = [], []
    for event in spec["fire_order"]:
        pieces = blocks[event]
        with files.npz(expected.per_fire[event]) as aggregate:
            if set(aggregate.files) != {"interval", "row", "col", "y", "t1", "hours", *("p_"+name for name in models)}:
                raise S.AdmissionError("Per-fire canonical aggregate schema changed")
            y = np.concatenate([arrays["y"] for _, _, arrays in pieces])
            counts = [len(arrays["y"]) for _, _, arrays in pieces]
            if (not np.array_equal(aggregate["y"], y)
                    or not np.array_equal(aggregate["interval"], np.repeat(np.arange(len(pieces)), counts))
                    or aggregate["interval"].dtype.kind not in "iu"
                    or aggregate["t1"].tolist() != [case.identity["cutoff"] for case, _, _ in pieces]
                    or aggregate["hours"].tolist() != [case.identity["hours"] for case, _, _ in pieces]):
                raise S.AdmissionError("Canonical interval membership, order or labels changed")
            for key in ("row", "col"):
                if not np.array_equal(aggregate[key], np.concatenate([arrays[key] for _, _, arrays in pieces])):
                    raise S.AdmissionError("Per-fire coordinates differ from every canonical case")
            bounds = np.r_[0, np.cumsum(counts)]
            for name in models:
                p = aggregate["p_"+name]
                if p.shape != y.shape or not np.isfinite(p).all() or ((p < 0) | (p > 1)).any():
                    raise S.AdmissionError("Invalid complete per-fire model probability")
                for index, (case, _, _) in enumerate(pieces):
                    with files.npz(case.entries) as individual:
                        value = individual["p_"+name]
                        if p.dtype != value.dtype or not np.array_equal(p[bounds[index]:bounds[index+1]], value):
                            raise S.AdmissionError("Individual/per-fire probabilities disagree")
            labels.append(y.astype(np.float64)); totals.append(len(y))
    points = {name: {key: canonical["models"][name]["pooled"].get(key) for key in S.ABSOLUTE.values()} for name in models}
    files.unchanged()
    return CanonicalCohort(expected, files, labels, points, totals)


def verify_both(expectations):
    if set(expectations) != {"us2024", "korea2025"}:
        raise S.AdmissionError("Both fixed cohorts must remain separately represented")
    results = {}
    for cohort in ("us2024", "korea2025"):
        try:
            results[cohort] = verify_cohort(expectations[cohort])
        except (S.AdmissionError, FileNotFoundError, KeyError, ValueError, TypeError) as error:
            results[cohort] = dict(cohort=cohort, status="UNAVAILABLE_ADMISSION_FAILURE", metrics=None,
                complete_cohort=False, reason=str(error), promotion_criteria_pass=False, execution_status=S.EXECUTION_STATUS)
    return results
