# Expected incident radiant heat flux

This separate, importable package produces **expected incident radiant heat spatial matrices** at upward-facing horizontal receiver points. Its principal output has units of **W/m²**. `ExpectedHeatFluxModel` converts probabilities of active burning at a specified instant. `WildfireHeatModel` connects an existing trained wildfire predictor to an explicit burning-time conversion and the same radiation calculation, returning mean flux over the next hour and incident radiant energy in **J/m²**. Optional `EcologicalFuelMaps` supplies aligned spatial dry-fuel loading from the existing LANDFIRE FCCS data.

The model superposes isotropic radiation from an elevated, uniformly emitting footprint for each source cell. It integrates each cell footprint through its solid angle rather than replacing a whole cell by one source point. It supports an affine metric grid, same-grid predictions, and arbitrary horizontal receiver coordinates.

**Probability alone cannot determine heat flux.** Supply the heat-release-rate density conditional on active burning, radiative fraction, and source elevation. Atmospheric transmission and receiver elevation are explicit parameters. The example values are synthetic illustrations; this package has not been calibrated or validated against wildfire heat-flux measurements.

## Input and output contract

For matrix shape `(H, W)`, `H` is the number of rows and `W` is the number of columns.

| Object | Meaning | Units / allowed values |
| --- | --- | --- |
| `p[row, col]` | Marginal probability that the entire cell is actively burning at the modeled instant | Finite number in `[0, 1]` |
| `grid` | Pixel-corner affine transform into a local projected metric plane | m |
| `heat_release_rate_density_w_m2` | Total heat release per unit horizontal source area, conditional on active burning | Nonnegative scalar or `(H, W)` array, W/m² |
| `radiative_fraction` | Fraction of conditional heat release emitted as thermal radiation | Scalar or `(H, W)` array in `[0, 1]` |
| `emission_height_m` | Common elevation of all source emitters | m; strictly above the receiver plane |
| `receiver_height_m` | Common elevation of upward-facing horizontal receivers | m; default `0` |
| `atmospheric_transmissivity` | Common fraction transmitted along every source-to-receiver path | Scalar in `[0, 1]`; default `1` |
| `incident_heat_flux_w_m2` | Expected radiant irradiance at receiver points | W/m² |
| `expected_total_radiant_power_w` | Expected radiant power emitted by all input cells before atmospheric loss | W |

`predict(p)` returns a `HeatFluxResult` with one receiver value at every cell center, with flux shape `(H, W)`. That value is a **point evaluation**, not an average over the receiver cell area. `predict_at_points(p, receiver_xy_m)` accepts `(N, 2)` receiver coordinates in the same metric system and returns a `HeatFluxResult` whose flux field has shape `(N,)`.

Conditional HRR density is averaged over the entire horizontal source-cell area. If only a fraction of the cell burns in an active state, scale that density by the burning-area fraction; do not apply a local flame density to the entire cell without accounting for partial coverage. The model still distributes the resulting averaged emission uniformly over the footprint, so subcell flame location is unresolved.

Unknown probabilities, masked values, NaNs, infinities, and values outside `[0, 1]` are rejected. Resolve missing coverage from the data provenance before using the model. A missing probability is not zero probability.

## Physics and derivation

Let index `i` range over the source cells. Let `B_i(t)` be the Bernoulli indicator of active burning in cell `i` at time `t`, with

\[
p_i(t)=\mathbb P(B_i(t)=1).
\]

Cell `i` has horizontal parallelogram footprint `D_i` of area `A`. Source emitters have common elevation `z_s`. A receiver has horizontal coordinate `x` and elevation `z_r`. Define separation `h = z_s - z_r > 0`. Let `q_i` be conditional total heat-release-rate density in W/m², `χ_i` its radiative fraction, and `τ` common atmospheric transmission. These parameters are prescribed deterministic quantities at the modeled instant.

1. **Activate radiant emission.** Given `B_i=1`, infinitesimal source area `dA` emits `χ_i q_i dA` W isotropically. Given `B_i=0`, it emits zero in this model.

2. **Spread power and project onto the receiver.** At distance `R`, isotropic power is divided by `4πR²`, then multiplied by receiver `cos θ`. For this horizontal receiver, `cos θ = h/R` and `R² = |s-x|²+h²`. This uses [NIST SP 1169, §6.1, Eq. (6.1)](https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.1169.pdf). Source elevation here is supplied by the caller; the package does not infer flame height using that report's correlations.

3. **Integrate the cell footprint.** Define the dimensionless transfer factor

   \[
   K_i(x)=\frac{1}{4\pi}\int_{D_i}
   \frac{h}{\bigl(|s-x|^2+h^2\bigr)^{3/2}}\,dA_s
   =\frac{\Omega_i(x)}{4\pi},
   \]

   where `Ω_i(x)` is the solid angle in steradians seen by the receiver. The realized incident flux is

   \[
   q''(x,t)=\tau\sum_i B_i(t)\chi_iq_iK_i(x).
   \]

4. **Take the expectation.** Linearity gives the implemented result

   \[
   \boxed{\mathbb E[q''(x,t)]=\tau\sum_i p_i(t)\chi_iq_iK_i(x).}
   \]

   Cell independence is **not required** for this mean. A joint burning distribution is needed for variance, quantiles, or exceedance probabilities; marginal probabilities alone do not provide those. If source strength is random, `χ_iq_i` must be its conditional expected radiant density given active burning for this expectation formula to hold.

The parallelogram is split into two triangles. For vectors `v₁, v₂, v₃` from receiver to triangle vertices and `r_j = |v_j|`, the positive triangle solid angle is

\[
\Omega_\triangle=2\operatorname{atan2}\!\left(
|\det(v_1,v_2,v_3)|,
r_1r_2r_3+r_1(v_2\cdot v_3)+r_2(v_3\cdot v_1)+r_3(v_1\cdot v_2)
\right).
\]

`atan2` retains the branch when the denominator is negative. The normalized-vector form is recorded in [Angelidis, *Spherical Springs*, §3.2](https://cs.otago.ac.nz/research/publications/oucs-2004-01.pdf), which credits [van Oosterom and Strackee (1983)](https://doi.org/10.1109/TBME.1983.325207). Multiplication by `r₁r₂r₃` gives the unnormalized form above.

Same-grid translation invariance makes this a convolution. `transfer_kernel(shape)` contains all needed offsets and has shape `(2H-1, 2W-1)`. Zero-padded FFT convolution computes the full source sum without periodic wraparound. The arbitrary-point method evaluates the same footprint relation directly in memory-bounded chunks.

### Fuel properties and conditional heat release

`CombustionParameters` supplies an optional constant-burning-rate conversion. Let `w` be dry fuel load in kg/m², `f` consumed fraction, `H_c` effective heat of combustion in J/kg, and `t_b` the assumed burning duration in seconds. Then

\[
\dot m''=\frac{wf}{t_b},\qquad q_i=\dot m''H_c=\frac{wfH_c}{t_b}.
\]

The mass-rate-times-heat relation is [NIST SP 1007, Eq. (1)](https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=911301). Constant mass loss over `t_b` is this package's additional assumption. The report cautions that complex/charring materials can have variable combustion heat; fuel load and duration alone do not establish a measured wildfire heat-release curve.

Use a mass convention consistent with the effective combustion heat. `consumed_fraction` controls consumed mass. Do not count an incomplete-combustion correction twice if it is already included in the supplied effective heat.

### Flux, power, and energy are distinct

Expected emitted radiant power and incident radiant energy per unit area are

\[
\mathbb E[P_{\mathrm{radiant}}(t)]=\sum_i p_i(t)\chi_iq_iA\quad[\mathrm W],
\qquad
E''(x)=\int_{t_0}^{t_1}\mathbb E[q''(x,t)]\,dt\quad[\mathrm{J/m^2}].
\]

- `result.incident_energy_j_m2(duration_s)` assumes the single flux field stays constant for the supplied exposure and returns `flux × duration`.
- `integrate_heat_flux(flux_w_m2, times_s)` integrates a sampled flux sequence along its first axis using the trapezoidal rule. Times are finite and strictly increasing.
- `result.incident_power_w(receiver_area_m2)` returns `flux × receiver area`.
- `result.incident_energy_j(duration_s, receiver_area_m2)` returns `flux × duration × receiver area`.

The area conversions are exact only when the finite receiver has uniform irradiance equal to the evaluated point value. Otherwise they are area-times-point-value approximations. Evaluate multiple points and integrate over the receiver area when spatial variation matters. The fuel `burning_duration_s` determines source strength; it does not automatically choose receiver exposure duration. Expected emitted power does not mean that all emission is intercepted by the receiver domain.

## Installation and use

From the workspace directory containing this folder:

```sh
python -m pip install -e './expected_heat_flux[demo]'
```

The core requires NumPy; the `demo` extra adds Matplotlib. An environment with these dependencies can also import directly from the workspace parent.

```python
import numpy as np
from expected_heat_flux import AffineGrid, CombustionParameters, ExpectedHeatFluxModel

# Replace with probabilities of ACTIVE BURNING at one stated time.
# This array and all parameters below are synthetic illustrations.
p = np.array([[0.0, 0.4, 0.0], [0.1, 0.8, 0.2]])
grid = AffineGrid.from_cell_size(
    cell_size_m=(10.0, 10.0),  # (row size, column size)
    origin_xy_m=(0.0, 0.0),   # outer corner of pixel (row=0, col=0)
    row_direction=1,         # row index increases with positive y
)
fuel = CombustionParameters(
    fuel_load_kg_m2=1.0,
    heat_of_combustion_j_kg=18_000_000.0,
    burning_duration_s=60.0,
    consumed_fraction=1.0,
)
model = ExpectedHeatFluxModel(
    grid=grid,
    heat_release_rate_density_w_m2=fuel.heat_release_rate_density_w_m2,
    radiative_fraction=0.30,
    emission_height_m=5.0,
    receiver_height_m=0.0,
    atmospheric_transmissivity=1.0,
)
result = model.predict(p)
flux_w_m2 = result.incident_heat_flux_w_m2
flux_kw_m2 = result.incident_heat_flux_kw_m2
constant_60s_energy_j_m2 = result.incident_energy_j_m2(duration_s=60.0)
print(flux_kw_m2)
print(result.expected_total_radiant_power_w)

# Coordinates are metric (x, y), in the same plane as grid.
receiver_xy_m = np.array([[15.0, 5.0], [100.0, 100.0]])
point_result = model.predict_at_points(p, receiver_xy_m)
point_flux_w_m2 = point_result.incident_heat_flux_w_m2
```

Spatially varying burning strength is supported through aligned `(H, W)` arrays for HRR density and/or radiative fraction. Those arrays describe conditional source strength; `p` describes activation probability.

For a time sequence:

```python
from expected_heat_flux import integrate_heat_flux

times_s = np.array([0.0, 30.0, 60.0])
p_over_time = np.stack([0.5 * p, p, 0.5 * p])
flux_over_time = np.stack([
    model.predict(p_t).incident_heat_flux_w_m2 for p_t in p_over_time
])
energy_j_m2 = integrate_heat_flux(flux_over_time, times_s)
```

### Coordinates and existing maps

`AffineGrid(transform=(a, b, c, d, e, f))` uses pixel corners:

\[
x=a\,\mathrm{column}+b\,\mathrm{row}+c,
\qquad y=d\,\mathrm{column}+e\,\mathrm{row}+f.
\]

Centers use `(column+0.5, row+0.5)`, and `cell_area_m2 = |ae-bd|`. Nondegenerate transforms may include rotation or shear. `from_cell_size` creates an axis-aligned grid; `row_direction=-1` supports a raster whose rows increase downward while map `y` increases northward. `centers(shape)` returns `(H, W, 2)` coordinates ordered `(x, y)`.

Use a suitable **projected metric coordinate system**, not longitude/latitude degrees. Source and receiver coordinates must have the same origin, orientation, units, and reference plane. Source/receiver elevations are constants; varying terrain is not represented.

The existing `wildfire_burned_area_hourly/probability_model` examples describe new-burn and/or cumulative burned-area probabilities. These differ from active-burning occupancy. Do not use those maps directly in `ExpectedHeatFluxModel` and do not replace their unknown-coverage NaNs with zero. The integrated `WildfireHeatModel` below supplies an explicit residence-time/burning-state model for this conversion.

Only cells in the input matrix emit. Real exterior sources may contribute near its boundaries; include sufficient source extent for the intended prediction. Arbitrary receiver points can lie outside the source grid.

## Reproducible synthetic example

From the workspace directory:

```sh
MPLCONFIGDIR=/tmp/expected_heat_flux_matplotlib \
  .venv/bin/python -m expected_heat_flux.example \
  --output expected_heat_flux/outputs/demo
```

Alternatively use `python` in an installed environment. The deterministic demo uses a 100 × 100 active-burning probability field, 10 m cells, fuel load 1 kg/m², effective combustion heat 18 MJ/kg, assumed source burning duration 60 s, radiative fraction 0.30, source elevation 5 m, receiver elevation 0 m, and transmission 1. Conditional HRR density is 300 kW/m²; conditional radiant density is 90 kW/m². These parameters illustrate the API and are not fitted fire parameters.

The saved artifacts are:

- `heat_flux_arrays.npz`: probability, incident flux in W/m² and kW/m², constant-60 s incident energy in J/m², center coordinates in metres, affine transform, and exposure duration.
- `summary.json`: probability meaning, units, geometry, parameters, flux statistics, emitted power, and one-cell analytic verification.
- `heat_flux_demo.png`: probability, expected radiant flux, and constant-60 s radiant energy with coordinate/colorbar units.

For a fully active 10 m square whose emitter plane is 5 m above its center receiver, solid angle is `2π/3` and transfer factor is `1/6`. The specified 90 kW/m² radiant density therefore gives exactly 15 kW/m² at the center. This is verification of the geometric model, not validation against fire measurements.

Run the model's numerical and input-contract tests from the workspace directory:

```sh
.venv/bin/python -m pytest expected_heat_flux/tests
```

These checks assess the implementation and its stated assumptions. Passing them does not establish wildfire prediction accuracy.

## Integrated wildfire forecast to expected heat matrices

`WildfireHeatModel` composes the maintained one-hour wildfire prediction package with this package's radiation operator. It safely distinguishes `DirectEnvironmentConditionedConvolution` checkpoints, whose evaluated probabilities are clipped direct scores, from the older `EnvironmentConditionedConvolution` checkpoints, whose probabilities use an exponential link. It loads the saved channel order, categorical vocabulary, learned parameters, and training-only normalization; it does not retrain or refit preprocessing on the forecast event. Unsupported checkpoint contracts are rejected by the corresponding loader.

The required input is **one current spatial snapshot**, with current cumulative burned state and raw environmental features in the checkpoint's required channel order. `predict_sample(sample)` accepts the dictionary returned by `WildfireSequenceDataset` for `sequence_length=1` and checks that its affine transform matches the configured metric grid. It reads `burned_area`, `features`, `channel_names`, their validity masks, and `affine_transform`; it does not use `newly_burned_area`, arrival-time arrays, or next-hour environmental inputs. Multiple non-singleton time or batch dimensions are rejected. A direct `predict(...)` method and a `predict_from_new_burn_probability(...)` method are also available.

### The temporal probability conversion

Fix a forecast interval of duration `Δ = 3600 s`. For source cell `i`, let `N_i` be the event that the cell first becomes burned during this interval, and let `q_i = P(N_i)`, the evaluation probability returned by the existing predictor. This `q_i` is an event probability, not the active-burning probability and not heat-release-rate density.

Conditional on `N_i`, this integration **assumes** an ignition time `U_i` uniform over `[0, Δ]`. After ignition, the cell emits at its prescribed constant conditional heat-release-rate density for `T_i = combustion.burning_duration_s > 0`, with active interval `[U_i, U_i + T_i)`. Cells with no new-burning event contribute zero through this new-ignition term. The original prediction model does not supply the ignition-time law or `T_i`; they are additional assumptions.

At elapsed time `u ∈ [0, Δ]`, the probability of active burning caused by a new ignition is

\[
p_i^{\mathrm{new}}(u)
=q_i\,\frac{\min(u,T_i)}{\Delta}.
\]

To obtain the time-average occupancy, integrate this probability over the forecast interval and divide by `Δ`:

\[
\overline p_i^{\mathrm{new}}
=\frac{1}{\Delta}\int_0^\Delta p_i^{\mathrm{new}}(u)\,du
=q_i
\begin{cases}
T_i/\Delta-\tfrac12(T_i/\Delta)^2,&T_i\le\Delta,\\
\tfrac12,&T_i\ge\Delta.
\end{cases}
\]

The active probability at the forecast endpoint is

\[
p_i^{\mathrm{new}}(\Delta)=q_i\min(T_i/\Delta,1).
\]

The mean flux matrix follows by passing `overline p` through the fixed linear radiation operator described above. Expected incident radiant energy during the forecast hour is the mean flux multiplied by `Δ`. Endpoint heat flux uses the endpoint occupancy rather than the mean occupancy. Earlier or later ignition distributions, transient combustion, and different residence times can change these outputs even when `q_i` is identical.

### Already-burned cells and currently active fires

A cell known to have burned already has zero probability of **first** new burning in the forecast interval. It can still be actively emitting at the cutoff. Cumulative burned state alone does not establish that active state, so the default forecast is the **heat contribution from new ignitions only**.

To include existing active fire, supply both `initial_active_burning_probability` and `initial_remaining_burning_duration_s`. Let `p_i^0` be the supplied initial active probability and `R_i ≥ 0` the remaining burning duration conditional on initial activity. The assumed active interval is `[0, R_i)`, so its mean occupancy is `p_i^0 min(R_i/Δ, 1)` and endpoint occupancy is `p_i^0` when `R_i > Δ`, otherwise zero. Extinction at `R_i = Δ` occurs exactly at the endpoint and therefore contributes zero there. Positive supplied initial activity must occur in known already-burned cells; it cannot overlap possible first-new-burning sources. No initial state is inferred from cumulative burned area.

### Missing probabilities and output meaning

The existing predictor has an explicit supported domain: missing burned-state context, missing features, boundary context, and contact eligibility can leave probabilities unknown. This integration preserves unknown probabilities as `NaN` and returns nonnegative radiation bounds rather than claiming those cells are unburned.

Because every supplied source with positive radiant density can contribute to every finite horizontal receiver under this geometry, one unresolved emitting source makes the **full supplied-domain expectation unknown at every receiver**. In that case `expected_heat_flux_w_m2` and `expected_incident_energy_j_m2` are all `NaN`, and `complete` is false. A missing source cannot be resolved merely by a valid probability at the receiver's own cell.

| Result field | Interpretation | Units |
| --- | --- | --- |
| `new_burn_probability`, `probability_valid` | Event probabilities and effective validity, including any explicitly supplied scenario values | Probability / boolean |
| `original_probability_valid`, `externally_supplied_probability_mask` | Availability before external estimates and the exact cells receiving supplied estimates | Boolean |
| `mean_active_burning_probability` | Active probability averaged over the hour, including supplied initial activity | Probability |
| `endpoint_active_burning_probability` | Active probability at the end of the hour | Probability |
| `expected_heat_flux_w_m2` | Full supplied-domain expected mean incident radiant flux when complete | W/m² |
| `known_source_heat_flux_w_m2` | Finite expected contribution from known source probabilities and supplied initial activity | W/m² |
| `heat_flux_lower_bound_w_m2`, `heat_flux_upper_bound_w_m2` | Mean-flux bounds allowing each unknown event probability to range from zero to one | W/m² |
| `expected_incident_energy_j_m2` | Full expected radiant energy per receiver area, when complete | J/m² |
| `incident_energy_lower_bound_j_m2`, `incident_energy_upper_bound_j_m2` | Corresponding hourly incident-energy bounds | J/m² |
| `endpoint_heat_flux_lower_bound_w_m2`, `endpoint_heat_flux_upper_bound_w_m2` | Bounds on incident radiant flux at the forecast endpoint | W/m² |
| `complete`, `metadata` | Full-expectation availability, physical scope, timing assumptions, coverage, and checkpoint provenance | Boolean / dictionary |

The known-source contribution equals the lower bound under this nonnegative source model. The lower endpoint of an unknown `q_i` is a mathematical bound, **not an observed zero**. These bounds condition on the supplied combustion parameters, timing assumptions, geometry, and finite source domain. They do not bound errors in those assumptions, external fires, or omitted convection. An upper bound is not an expected estimate. A separately justified `unknown_new_burn_probability` scalar or map may be explicitly supplied as a scenario; metadata records the externally supplied entries.

### Ecological fuel data

Ecological fuel loading is physically relevant because conditional heat-release density is proportional to the consumed dry fuel mass per area. `EcologicalFuelMaps.from_fccs_rasters(...)` reads the bundle's existing `total_available_fuel_loading_tons_per_acre_375m.tif` and `fuel_loading_lookup_coverage_fraction_375m.tif`. Despite the first filename, these values are **reference fuelbed loading estimates**, not measurements of event-date available or consumed fuel. [LANDFIRE's FCCS documentation](https://www.landfire.gov/fuel/fccs) describes fuelbed assignment, reference-library attributes, and loading in tons per acre. [US Forest Service FCCS technical documentation, PNW-GTR-887](https://research.fs.usda.gov/treesearch/45283) distinguishes fuel strata, fuel characteristics, and available-fuel potentials.

The reader verifies equal shapes, affine transforms, and projected CRSs in metres, and optionally checks them against the probability grid. It converts U.S. short tons per acre to kg/m² using

\[
1\ \mathrm{short\ ton/acre}
=\frac{907.18474\ \mathrm{kg}}{4046.8564224\ \mathrm{m^2}}
\approx0.224170231\ \mathrm{kg/m^2}.
\]

Its `fuel_load_kg_m2` stores the mapped portion's mean loading. `coverage_fraction = c_i` indicates the mapped fraction of the whole cell. `valid` requires a readable loading and coverage at least `1 - full_coverage_tolerance`, with default tolerance `10⁻⁶`. Missing or partial coverage does not imply no fuel.

By default, `combustion_parameters(...)` rejects incomplete fuel coverage. If a caller explicitly supplies unmapped-fuel loading `w_i^fallback`, it forms the whole-cell estimate

\[
w_i=c_iw_i^{\mathrm{mapped}}+(1-c_i)w_i^{\mathrm{fallback}}.
\]

Unreadable loading or coverage uses the explicit fallback for the whole cell. This preserves the known mapped contribution without silently treating the unknown fraction as zero. The reader exposes reference-loading provenance, file hashes, coverage, and a reference-conditioned nonnegative loading lower bound. A reference-conditioned lower bound is not a guaranteed lower bound on true field fuel mass.

Fuel data can improve the spatial specificity of the assumed source strengths. **Measured heat-prediction improvement has not been established.** Consumed fraction, effective heat of combustion, radiative fraction, duration, and emitter elevation remain explicit supplied assumptions. The package permits aligned spatial arrays for combustion and radiative fraction; it does not assign fuel mass from biome codes or canopy percentages without a physical conversion. [NIST TN 2314](https://www.nist.gov/publications/global-burning-properties-little-bluestem-excelsior-and-douglas-fir) shows moisture dependence in measured vegetation burning properties, but a relationship fitted for Douglas-fir samples does not justify automatically damping every landscape fuel. No uncalibrated universal moisture correction is applied.

### Importable integration example

The standalone radiation API requires only NumPy. Ecological GeoTIFF reading requires Rasterio. Checkpoint integration additionally requires PyTorch and the existing `wildfire_burned_area_hourly` package on the Python import path; this heat package does not copy that prediction package or its trained data into its wheel. `WildfireSequenceDataset` also needs Pandas and Affine. The optional `integration` dependency group declares these libraries. In this workspace the demonstrated runtime is `.venv/bin/python` with PyTorch 2.5.1; the maintained prediction project's pinned environment uses Python 3.12.

```python
from pathlib import Path
from expected_heat_flux import (
    AffineGrid, EcologicalFuelMaps, WildfireHeatModel,
)

# sample is one cutoff snapshot from WildfireSequenceDataset(sequence_length=1).
# The dataset must use the saved checkpoint channel schema and categorical classes.
grid = AffineGrid(tuple(sample["affine_transform"].tolist()))
shape = tuple(sample["burned_area"].shape[-2:])
fuel_dir = Path("wildfire_burned_area_hourly/environmental_data/regions") / sample["event_id"] / "fuel"
ecology = EcologicalFuelMaps.from_fccs_rasters(
    fuel_dir / "total_available_fuel_loading_tons_per_acre_375m.tif",
    fuel_dir / "fuel_loading_lookup_coverage_fraction_375m.tif",
    grid=grid, expected_shape=shape,
)

# These combustion values and the explicit fallback illustrate the API.
# Replace them with assumptions justified for the event and combustion phase.
combustion = ecology.combustion_parameters(
    heat_of_combustion_j_kg=18_000_000.0,
    burning_duration_s=300.0,
    consumed_fraction=0.10,
    fallback_fuel_load_kg_m2=10.0,
)
model = WildfireHeatModel.from_checkpoint(
    checkpoint_path,
    grid=grid,
    combustion=combustion,
    radiative_fraction=0.30,
    emission_height_m=5.0,
    interval_s=3600.0,
    device="cpu",
)
result = model.predict_sample(sample)

# All returned spatial fields have shape (H, W).
full_expected_heat = result.expected_heat_flux_w_m2
known_source_contribution = result.known_source_heat_flux_w_m2
lower = result.heat_flux_lower_bound_w_m2
upper = result.heat_flux_upper_bound_w_m2
hourly_energy = result.expected_incident_energy_j_m2
print(result.complete, result.metadata)
```

For an already-saved one-hour event-probability map, call `model.predict_from_new_burn_probability(q, probability_valid=valid)` using `[H, W]` arrays. A `WildfireHeatModel` with `predictor=None` can perform this physical conversion without importing PyTorch. The temporal helpers `ignition_to_active_probability(...)` and `initial_active_occupancy(...)` are also public and use seconds explicitly.

### Reproducible integrated run and saved results

From the workspace directory:

```sh
MPLCONFIGDIR=/tmp/expected_heat_flux_matplotlib \
  .venv/bin/python -m expected_heat_flux.integrated_example \
  --output expected_heat_flux/outputs/integrated_demo
```

The deterministic default input is Fish Creek (`WY-BTF-002416_FishCreek`), cutoff **2024-08-23 00:00 UTC**, using the existing signed 5 × 5 direct-convolution checkpoint in `wildfire_burned_area_hourly/probability_model/training_runs/20261007_1h_direct_convolution_signed/5x5/fitted/checkpoint.pt`. This event is the saved training run's test split. The original 103 × 73 grid is retained in EPSG:5070 with 375 m cells; no image stretching or resampling occurs. `daily_policy="completed_day"` selects environmental intervals ended by the cutoff, and the example verifies these interval-end timestamps before reporting its output. The demonstration runs on CPU.

The saved run has 225 known event probabilities, including 191 known already-burned cells with zero first-new-burning probability and 34 eligible remaining cells. Twenty-three cells have positive predicted event probability; their probability sum is approximately 0.897447. The other 7,294 event probabilities remain unknown. These are forecast-support counts, not a statement that only 225 current burned-state observations exist. The full expected heat matrix is consequently unavailable. The saved finite known-source mean-flux contribution ranges from approximately `4.13 × 10⁻⁶` to `147.877 W/m²`; it is the conditional lower-bound contribution, not total ongoing-fire heat. The upper bound can be very broad because it allows all unknown source probabilities to be one.

Fuel lookup has complete coverage in 6,016 of 7,519 cells. The remaining cells use the explicitly declared fallback only for their unmapped fraction, or the whole cell if unreadable. The demo compares these reference-conditioned strengths against an otherwise identical uniform `10 kg/m²` fuel assumption using exactly the same probability map. The maximum absolute difference in known-source mean flux is approximately `84.088 W/m²`; this is a sensitivity result, not a heat-prediction skill metric.

The saved artifacts are:

- `outputs/integrated_demo/integrated_heat_arrays.npz`: all returned spatial matrices, validity masks, reference and fallback-blended fuel loads, lookup coverage, uniform-fuel comparison matrices, current burned-state inputs, feature-validity masks, checkpoint channel names, and the metric affine transform. Unknown probabilities and unavailable full expectations remain `NaN`; NumPy archives preserve them without object pickling.
- `outputs/integrated_demo/summary.json`: checkpoint hash, source-data hashes, cutoff and geometry, input contract, excluded future/arrival fields, current-fire exclusion, coverage counts, physical assumptions, missing-data bound meaning, matrix statistics, and ecological sensitivity. Unavailable statistics use JSON `null` rather than nonstandard JSON `NaN`.
- `outputs/integrated_demo/integrated_heat_demo.png`: predicted event probabilities with unknown cells shown in gray, reference-conditioned fuel, mean active occupancy, known-source expected mean flux, upper bound, and ecological-versus-uniform difference. The upper-bound panel is labeled as a bound rather than an expected estimate.

The loader reconstructs current burned state from a **retrospective arrival-time surface and final-extent-derived coverage**. Not consuming its next-hour labels prevents a particular direct input leak, but does not turn this example into a validated operational forecast. The event is held out in the saved probability-model split; that does not establish measured radiant-heat accuracy. No measured heat-flux calibration, ecological improvement experiment, or total-heat validation is claimed.

## Limits and source record

The calculation integrates the stated uniform isotropic source footprint exactly, up to floating-point error. That footprint is a distribution of emitters, not an opaque Lambertian flame surface. Flame geometry, self-obscuration, terrain blocking, directional emission, smoke, path-dependent transmission, and varying source elevation require additional modeling.

[NISTIR 6546](https://nvlpubs.nist.gov/nistpubs/Legacy/IR/nistir6546.pdf) discusses close-range limitations of representing a whole fire by one point. Footprint integration removes the cell-center source quadrature error; it does not establish real near-flame accuracy or validity under flame immersion.

The output is **incident thermal radiation**. It excludes convection, contact heating, absorbed/net heat, receiver temperature, ignition, injury, and safety boundaries. [Frankman et al. (2012)](https://research.fs.usda.gov/treesearch/42185) measured both radiant and convective transfer in wildland fires and found fuel/environment dependence. Total heat or receiver temperature needs additional transport terms and receiver properties.

[sources.json](sources.json) records primary URLs, exact supported roles, and additional model assumptions. The original van Oosterom–Strackee DOI is retained for attribution; the accessible Otago report was used to verify the formula. No synthetic parameter is claimed to be a universal wildfire constant.
