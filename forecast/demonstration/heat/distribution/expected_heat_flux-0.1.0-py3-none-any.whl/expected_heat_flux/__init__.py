"""Expected incident radiant heat from active-burning probability rasters."""

from .model import (
    AffineGrid,
    CombustionParameters,
    ExpectedHeatFluxModel,
    HeatFluxResult,
    integrate_heat_flux,
)

__all__ = [
    "AffineGrid",
    "CombustionParameters",
    "ExpectedHeatFluxModel",
    "HeatFluxResult",
    "integrate_heat_flux",
]

__version__ = "0.1.0"
