# Expected incident radiant heat flux

This separate, importable model converts a spatial matrix of **probabilities that cells are actively burning at a specified time** into **expected incident radiant heat flux** at upward-facing horizontal receiver points. Its principal output has units of **W/m²**. It also exposes kW/m², emitted radiant power in W, and conversions to incident radiant energy in J/m² or J.

The model superposes isotropic radiation from an elevated, uniformly emitting footprint for each source cell. It integrates each cell footprint through its solid angle rather than replacing a whole cell by one source point. It supports an affine metric grid, same-grid predictions, and arbitrary horizontal receiver coordinates.

**Probability alone cannot determine heat flux.** Supply the heat-release-rate density conditional on active burning, radiative fraction, and source elevation. Atmospheric transmission and receiver elevation are explicit parameters. The example values are synthetic illustrations; this package has not been calibrated or validated against wildfire heat-flux measurements.

## Input and output contract

For matrix shape `(H, W)`, `H` is the number of rows and `W` is the number of columns.

| Object | Meaning | Units / allowed values |
| --- | --- | --- |
| `p[row, col]` | Marginal probability that the entire cell is actively burning at the modeled instant | Finite number in `[0, 1]` |
| `grid` | Pixel-corner affine transform into a local projected metric plane | m |
| `heat_release_rate_density_w_m2` | Total heat release per unit horizontal source area, conditional on active burning | Nonnegative scalar or `(H, W)` array, W/m² |
| `radiative_fraction` | Fraction of conditional heat release emitted as thermal radiation | Scalar or `(H, W)` array in `[0, 1]` |
| `emission_height_m` | Common elevation of all source emitters | m; strictly above the receiver plane |
| `receiver_height_m` | Common elevation of upward-facing horizontal receivers | m; default `0` |
| `atmospheric_transmissivity` | Common fraction transmitted along every source-to-receiver path | Scalar in `[0, 1]`; default `1` |
| `incident_heat_flux_w_m2` | Expected radiant irradiance at receiver points | W/m² |
| `expected_total_radiant_power_w` | Expected radiant power emitted by all input cells before atmospheric loss | W |

`predict(p)` returns a `HeatFluxResult` with one receiver value at every cell center, with flux shape `(H, W)`. That value is a **point evaluation**, not an average over the receiver cell area. `predict_at_points(p, receiver_xy_m)` accepts `(N, 2)` receiver coordinates in the same metric system and returns a `HeatFluxResult` whose flux field has shape `(N,)`.

Conditional HRR density is averaged over the entire horizontal source-cell area. If only a fraction of the cell burns in an active state, scale that density by the burning-area fraction; do not apply a local flame density to the entire cell without accounting for partial coverage. The model still distributes the resulting averaged emission uniformly over the footprint, so subcell flame location is unresolved.

Unknown probabilities, masked values, NaNs, infinities, and values outside `[0, 1]` are rejected. Resolve missing coverage from the data provenance before using the model. A missing probability is not zero probability.

## Physics and derivation

Let index `i` range over the source cells. Let `B_i(t)` be the Bernoulli indicator of active burning in cell `i` at time `t`, with

\[
p_i(t)=\mathbb P(B_i(t)=1).
\]

Cell `i` has horizontal parallelogram footprint `D_i` of area `A`. Source emitters have common elevation `z_s`. A receiver has horizontal coordinate `x` and elevation `z_r`. Define separation `h = z_s - z_r > 0`. Let `q_i` be conditional total heat-release-rate density in W/m², `χ_i` its radiative fraction, and `τ` common atmospheric transmission. These parameters are prescribed deterministic quantities at the modeled instant.

1. **Activate radiant emission.** Given `B_i=1`, infinitesimal source area `dA` emits `χ_i q_i dA` W isotropically. Given `B_i=0`, it emits zero in this model.

2. **Spread power and project onto the receiver.** At distance `R`, isotropic power is divided by `4πR²`, then multiplied by receiver `cos θ`. For this horizontal receiver, `cos θ = h/R` and `R² = |s-x|²+h²`. This uses [NIST SP 1169, §6.1, Eq. (6.1)](https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.1169.pdf). Source elevation here is supplied by the caller; the package does not infer flame height using that report's correlations.

3. **Integrate the cell footprint.** Define the dimensionless transfer factor

   \[
   K_i(x)=\frac{1}{4\pi}\int_{D_i}
   \frac{h}{\bigl(|s-x|^2+h^2\bigr)^{3/2}}\,dA_s
   =\frac{\Omega_i(x)}{4\pi},
   \]

   where `Ω_i(x)` is the solid angle in steradians seen by the receiver. The realized incident flux is

   \[
   q''(x,t)=\tau\sum_i B_i(t)\chi_iq_iK_i(x).
   \]

4. **Take the expectation.** Linearity gives the implemented result

   \[
   \boxed{\mathbb E[q''(x,t)]=\tau\sum_i p_i(t)\chi_iq_iK_i(x).}
   \]

   Cell independence is **not required** for this mean. A joint burning distribution is needed for variance, quantiles, or exceedance probabilities; marginal probabilities alone do not provide those. If source strength is random, `χ_iq_i` must be its conditional expected radiant density given active burning for this expectation formula to hold.

The parallelogram is split into two triangles. For vectors `v₁, v₂, v₃` from receiver to triangle vertices and `r_j = |v_j|`, the positive triangle solid angle is

\[
\Omega_\triangle=2\operatorname{atan2}\!\left(
|\det(v_1,v_2,v_3)|,
r_1r_2r_3+r_1(v_2\cdot v_3)+r_2(v_3\cdot v_1)+r_3(v_1\cdot v_2)
\right).
\]

`atan2` retains the branch when the denominator is negative. The normalized-vector form is recorded in [Angelidis, *Spherical Springs*, §3.2](https://cs.otago.ac.nz/research/publications/oucs-2004-01.pdf), which credits [van Oosterom and Strackee (1983)](https://doi.org/10.1109/TBME.1983.325207). Multiplication by `r₁r₂r₃` gives the unnormalized form above.

Same-grid translation invariance makes this a convolution. `transfer_kernel(shape)` contains all needed offsets and has shape `(2H-1, 2W-1)`. Zero-padded FFT convolution computes the full source sum without periodic wraparound. The arbitrary-point method evaluates the same footprint relation directly in memory-bounded chunks.

### Fuel properties and conditional heat release

`CombustionParameters` supplies an optional constant-burning-rate conversion. Let `w` be dry fuel load in kg/m², `f` consumed fraction, `H_c` effective heat of combustion in J/kg, and `t_b` the assumed burning duration in seconds. Then

\[
\dot m''=\frac{wf}{t_b},\qquad q_i=\dot m''H_c=\frac{wfH_c}{t_b}.
\]

The mass-rate-times-heat relation is [NIST SP 1007, Eq. (1)](https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=911301). Constant mass loss over `t_b` is this package's additional assumption. The report cautions that complex/charring materials can have variable combustion heat; fuel load and duration alone do not establish a measured wildfire heat-release curve.

Use a mass convention consistent with the effective combustion heat. `consumed_fraction` controls consumed mass. Do not count an incomplete-combustion correction twice if it is already included in the supplied effective heat.

### Flux, power, and energy are distinct

Expected emitted radiant power and incident radiant energy per unit area are

\[
\mathbb E[P_{\mathrm{radiant}}(t)]=\sum_i p_i(t)\chi_iq_iA\quad[\mathrm W],
\qquad
E''(x)=\int_{t_0}^{t_1}\mathbb E[q''(x,t)]\,dt\quad[\mathrm{J/m^2}].
\]

- `result.incident_energy_j_m2(duration_s)` assumes the single flux field stays constant for the supplied exposure and returns `flux × duration`.
- `integrate_heat_flux(flux_w_m2, times_s)` integrates a sampled flux sequence along its first axis using the trapezoidal rule. Times are finite and strictly increasing.
- `result.incident_power_w(receiver_area_m2)` returns `flux × receiver area`.
- `result.incident_energy_j(duration_s, receiver_area_m2)` returns `flux × duration × receiver area`.

The area conversions are exact only when the finite receiver has uniform irradiance equal to the evaluated point value. Otherwise they are area-times-point-value approximations. Evaluate multiple points and integrate over the receiver area when spatial variation matters. The fuel `burning_duration_s` determines source strength; it does not automatically choose receiver exposure duration. Expected emitted power does not mean that all emission is intercepted by the receiver domain.

## Installation and use

From the workspace directory containing this folder:

```sh
python -m pip install -e './expected_heat_flux[demo]'
```

The core requires NumPy; the `demo` extra adds Matplotlib. An environment with these dependencies can also import directly from the workspace parent.

```python
import numpy as np
from expected_heat_flux import AffineGrid, CombustionParameters, ExpectedHeatFluxModel

# Replace with probabilities of ACTIVE BURNING at one stated time.
# This array and all parameters below are synthetic illustrations.
p = np.array([[0.0, 0.4, 0.0], [0.1, 0.8, 0.2]])
grid = AffineGrid.from_cell_size(
    cell_size_m=(10.0, 10.0),  # (row size, column size)
    origin_xy_m=(0.0, 0.0),   # outer corner of pixel (row=0, col=0)
    row_direction=1,         # row index increases with positive y
)
fuel = CombustionParameters(
    fuel_load_kg_m2=1.0,
    heat_of_combustion_j_kg=18_000_000.0,
    burning_duration_s=60.0,
    consumed_fraction=1.0,
)
model = ExpectedHeatFluxModel(
    grid=grid,
    heat_release_rate_density_w_m2=fuel.heat_release_rate_density_w_m2,
    radiative_fraction=0.30,
    emission_height_m=5.0,
    receiver_height_m=0.0,
    atmospheric_transmissivity=1.0,
)
result = model.predict(p)
flux_w_m2 = result.incident_heat_flux_w_m2
flux_kw_m2 = result.incident_heat_flux_kw_m2
constant_60s_energy_j_m2 = result.incident_energy_j_m2(duration_s=60.0)
print(flux_kw_m2)
print(result.expected_total_radiant_power_w)

# Coordinates are metric (x, y), in the same plane as grid.
receiver_xy_m = np.array([[15.0, 5.0], [100.0, 100.0]])
point_result = model.predict_at_points(p, receiver_xy_m)
point_flux_w_m2 = point_result.incident_heat_flux_w_m2
```

Spatially varying burning strength is supported through aligned `(H, W)` arrays for HRR density and/or radiative fraction. Those arrays describe conditional source strength; `p` describes activation probability.

For a time sequence:

```python
from expected_heat_flux import integrate_heat_flux

times_s = np.array([0.0, 30.0, 60.0])
p_over_time = np.stack([0.5 * p, p, 0.5 * p])
flux_over_time = np.stack([
    model.predict(p_t).incident_heat_flux_w_m2 for p_t in p_over_time
])
energy_j_m2 = integrate_heat_flux(flux_over_time, times_s)
```

### Coordinates and existing maps

`AffineGrid(transform=(a, b, c, d, e, f))` uses pixel corners:

\[
x=a\,\mathrm{column}+b\,\mathrm{row}+c,
\qquad y=d\,\mathrm{column}+e\,\mathrm{row}+f.
\]

Centers use `(column+0.5, row+0.5)`, and `cell_area_m2 = |ae-bd|`. Nondegenerate transforms may include rotation or shear. `from_cell_size` creates an axis-aligned grid; `row_direction=-1` supports a raster whose rows increase downward while map `y` increases northward. `centers(shape)` returns `(H, W, 2)` coordinates ordered `(x, y)`.

Use a suitable **projected metric coordinate system**, not longitude/latitude degrees. Source and receiver coordinates must have the same origin, orientation, units, and reference plane. Source/receiver elevations are constants; varying terrain is not represented.

The existing `wildfire_burned_area_hourly/probability_model` examples describe new-burn and/or cumulative burned-area probabilities. These differ from active-burning occupancy. Do not use those maps directly and do not replace their unknown-coverage NaNs with zero. Conversion requires a separately justified residence-time/burning-state model and suitable temporal information.

Only cells in the input matrix emit. Real exterior sources may contribute near its boundaries; include sufficient source extent for the intended prediction. Arbitrary receiver points can lie outside the source grid.

## Reproducible synthetic example

From the workspace directory:

```sh
MPLCONFIGDIR=/tmp/expected_heat_flux_matplotlib \
  .venv/bin/python -m expected_heat_flux.example \
  --output expected_heat_flux/outputs/demo
```

Alternatively use `python` in an installed environment. The deterministic demo uses a 100 × 100 active-burning probability field, 10 m cells, fuel load 1 kg/m², effective combustion heat 18 MJ/kg, assumed source burning duration 60 s, radiative fraction 0.30, source elevation 5 m, receiver elevation 0 m, and transmission 1. Conditional HRR density is 300 kW/m²; conditional radiant density is 90 kW/m². These parameters illustrate the API and are not fitted fire parameters.

The saved artifacts are:

- `heat_flux_arrays.npz`: probability, incident flux in W/m² and kW/m², constant-60 s incident energy in J/m², center coordinates in metres, affine transform, and exposure duration.
- `summary.json`: probability meaning, units, geometry, parameters, flux statistics, emitted power, and one-cell analytic verification.
- `heat_flux_demo.png`: probability, expected radiant flux, and constant-60 s radiant energy with coordinate/colorbar units.

For a fully active 10 m square whose emitter plane is 5 m above its center receiver, solid angle is `2π/3` and transfer factor is `1/6`. The specified 90 kW/m² radiant density therefore gives exactly 15 kW/m² at the center. This is verification of the geometric model, not validation against fire measurements.

Run the model's numerical and input-contract tests from the workspace directory:

```sh
.venv/bin/python -m pytest expected_heat_flux/tests
```

These checks assess the implementation and its stated assumptions. Passing them does not establish wildfire prediction accuracy.

## Limits and source record

The calculation integrates the stated uniform isotropic source footprint exactly, up to floating-point error. That footprint is a distribution of emitters, not an opaque Lambertian flame surface. Flame geometry, self-obscuration, terrain blocking, directional emission, smoke, path-dependent transmission, and varying source elevation require additional modeling.

[NISTIR 6546](https://nvlpubs.nist.gov/nistpubs/Legacy/IR/nistir6546.pdf) discusses close-range limitations of representing a whole fire by one point. Footprint integration removes the cell-center source quadrature error; it does not establish real near-flame accuracy or validity under flame immersion.

The output is **incident thermal radiation**. It excludes convection, contact heating, absorbed/net heat, receiver temperature, ignition, injury, and safety boundaries. [Frankman et al. (2012)](https://research.fs.usda.gov/treesearch/42185) measured both radiant and convective transfer in wildland fires and found fuel/environment dependence. Total heat or receiver temperature needs additional transport terms and receiver properties.

[sources.json](sources.json) records primary URLs, exact supported roles, and additional model assumptions. The original van Oosterom–Strackee DOI is retained for attribution; the accessible Otago report was used to verify the formula. No synthetic parameter is claimed to be a universal wildfire constant.
