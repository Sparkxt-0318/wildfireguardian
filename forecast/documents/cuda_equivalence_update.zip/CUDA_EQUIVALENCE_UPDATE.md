# CUDA equivalence verification update

Apply this update from the Linux project root after the failed process has exited.
It adds a scoped full-float32 verification helper, updates the portable dispatch,
and supplies an entry point for fresh prepared caches. No frozen training file,
data cache, checkpoint, optimizer state, history or protocol is included.

After transferring cuda_equivalence_update.zip to your Linux machine, extract:

    cd /home/movinggk/wildfire
    unzip -o /path/to/cuda_equivalence_update.zip -d .

Then repeat your original portable_search command with exactly the same options,
cache/data/output paths and CUDA device. For unchanged default settings:

    .venv/bin/python -m wildfire_burned_area_hourly.portable_search run --device cuda

If the original command used custom options or cuda:0, retain those options
and device spelling rather than substituting the default example.

Do not edit kernel_search_multiscale.py or delete the saved run. At the reported
selected-checkpoint failure, the final optimizer/RNG state was already committed.
A same-output retry at the completed epoch budget runs verification without
additional optimizer steps; previous completed candidates are skipped.

Check actual GPU equivalence before resuming, if pytest is installed:

    .venv/bin/python -m pytest -q tests/probability/test_cuda_equivalence.py -k real_cuda

The eight real-CUDA tests must run on available CUDA hardware. A skip does not
verify GPU behavior. The developer machine does not have CUDA; local checks
cover CPU math, precision restoration, deliberate mismatch rejection and saved
run continuation.

For a freshly prepared cache without original-cache relocation, use:

    .venv/bin/python -m wildfire_burned_area_hourly.precision_search run --device cuda --cache /path/to/prepared_all --output /path/to/existing_or_new_output

Retain all other original search options when resuming. This entry forwards the
unchanged original CLI, sets MPS fallback before PyTorch imports, and scopes the
same correction to equivalence checks. CUDA candidate summaries record the policy.

The cached path uses linear operations while public inference uses convolutions.
PyTorch 2.5.1 has independent TF32 defaults for those paths. The helper disables
TF32 only during equivalence verification and restores training precision after
success or failure. The original tolerances and CPU float64 reference remain.
An actual implementation discrepancy still raises an assertion. Forced TF32 via
TORCH_ALLOW_TF32_CUBLAS_OVERRIDE=1 is rejected; disabling a training-wide override
requires a separate experiment rather than changing a resumed trajectory.

Primary reference:
https://github.com/pytorch/pytorch/blob/v2.5.1/docs/source/notes/cuda.rst
