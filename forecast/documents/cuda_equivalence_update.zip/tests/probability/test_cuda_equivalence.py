"""Strict verification preserves training settings and rejects real mismatches."""

from types import SimpleNamespace

import numpy as np
import pytest
import torch

from wildfire_burned_area_hourly.probability_model import kernel_search_multiscale as search
from wildfire_burned_area_hourly.probability_model.cache import CachedSplit
from wildfire_burned_area_hourly.probability_model.cuda_equivalence import (
    full_precision_cuda_verification,
    strict_cuda_equivalence,
)


def _settings():
    return dict(
        cudnn_allow_tf32=torch.backends.cudnn.allow_tf32,
        matmul_allow_tf32=torch.backends.cuda.matmul.allow_tf32,
        float32_matmul_precision=torch.get_float32_matmul_precision(),
        cudnn_enabled=torch.backends.cudnn.enabled,
        cudnn_benchmark=torch.backends.cudnn.benchmark,
        cudnn_deterministic=torch.backends.cudnn.deterministic,
        cudnn_benchmark_limit=torch.backends.cudnn.benchmark_limit,
    )


def _restore(settings):
    torch.backends.cuda.matmul.allow_tf32 = settings["matmul_allow_tf32"]
    torch.set_float32_matmul_precision(settings["float32_matmul_precision"])
    torch.backends.cudnn.allow_tf32 = settings["cudnn_allow_tf32"]
    torch.backends.cudnn.enabled = settings["cudnn_enabled"]
    torch.backends.cudnn.benchmark = settings["cudnn_benchmark"]
    torch.backends.cudnn.deterministic = settings["cudnn_deterministic"]
    torch.backends.cudnn.benchmark_limit = settings["cudnn_benchmark_limit"]


@pytest.fixture(autouse=True)
def _restore_backend_settings(monkeypatch):
    # The environment override is tested explicitly; it must not affect other
    # precision tests or inherit a caller's forced-TF32 setting.
    monkeypatch.delenv("TORCH_ALLOW_TF32_CUBLAS_OVERRIDE", raising=False)
    initial = _settings()
    threads = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    _restore(initial)
    torch.set_num_threads(threads)


def _assert_full_precision(previous):
    actual = _settings()
    assert actual["cudnn_allow_tf32"] is False
    assert actual["matmul_allow_tf32"] is False
    assert actual["float32_matmul_precision"] == "highest"
    for key in ("cudnn_enabled", "cudnn_benchmark", "cudnn_deterministic", "cudnn_benchmark_limit"):
        assert actual[key] == previous[key]


@pytest.mark.parametrize("precision", ["highest", "high", "medium"])
@pytest.mark.parametrize("fail", [False, True])
def test_precision_settings_are_restored_after_success_and_exception(precision, fail):
    torch.set_float32_matmul_precision(precision)
    torch.backends.cudnn.allow_tf32 = True
    # Nondefault unrelated cuDNN flags reveal accidental use of flags() defaults.
    torch.backends.cudnn.enabled = True
    torch.backends.cudnn.benchmark = True
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark_limit = 7
    previous = _settings()

    def exercise():
        with full_precision_cuda_verification() as saved:
            assert saved == {key: previous[key] for key in (
                "cudnn_allow_tf32", "matmul_allow_tf32", "float32_matmul_precision",
            )}
            _assert_full_precision(previous)
            if fail:
                raise ValueError("synthetic verification failure")

    if fail:
        with pytest.raises(ValueError, match="synthetic verification failure"):
            exercise()
    else:
        exercise()
    assert _settings() == previous


def test_forced_tf32_environment_is_rejected_without_mutation(monkeypatch):
    monkeypatch.setenv("TORCH_ALLOW_TF32_CUBLAS_OVERRIDE", "1")
    previous = _settings()
    with pytest.raises(RuntimeError, match="TORCH_ALLOW_TF32_CUBLAS_OVERRIDE"):
        with full_precision_cuda_verification():
            pytest.fail("A forced-TF32 context must not be entered")
    assert _settings() == previous


@pytest.mark.parametrize("device", [torch.device("cpu"), "mps"])
def test_cpu_and_mps_delegate_directly_without_precision_changes(device, monkeypatch):
    monkeypatch.setenv("TORCH_ALLOW_TF32_CUBLAS_OVERRIDE", "1")
    previous = _settings()
    result = {"original": object()}
    arguments = (object(), object(), object(), object(), "cnn", device)

    def original(*received):
        assert all(actual is expected for actual, expected in zip(received, arguments, strict=True))
        assert _settings() == previous
        return result

    namespace = SimpleNamespace(verify_equivalence=original)
    with strict_cuda_equivalence(namespace):
        assert namespace.verify_equivalence(*arguments) is result
        assert _settings() == previous
    assert namespace.verify_equivalence is original


def test_cuda_delegate_uses_full_precision_then_restores_training_settings():
    torch.set_float32_matmul_precision("medium")
    torch.backends.cudnn.allow_tf32 = True
    previous = _settings()
    original_result = dict(device_float32_max_error=1e-7, cpu_float64_max_error=1e-16)
    arguments = (object(), object(), object(), object(), "cnn", torch.device("cuda"))

    def original(*received):
        assert all(actual is expected for actual, expected in zip(received, arguments, strict=True))
        _assert_full_precision(previous)
        return original_result

    namespace = SimpleNamespace(verify_equivalence=original)
    with strict_cuda_equivalence(namespace):
        wrapped = namespace.verify_equivalence
        result = wrapped(*arguments)
        assert result["device_float32_max_error"] == original_result["device_float32_max_error"]
        assert result["cpu_float64_max_error"] == original_result["cpu_float64_max_error"]
        assert "cuda_verification_precision" not in original_result
        policy = result["cuda_verification_precision"]
        assert policy["cudnn_allow_tf32"] is False
        assert policy["matmul_allow_tf32"] is False
        assert policy["float32_matmul_precision"] == "highest"
        assert policy["training_settings_restored"] == {
            key: previous[key] for key in (
                "cudnn_allow_tf32", "matmul_allow_tf32", "float32_matmul_precision",
            )
        }
        assert _settings() == previous
        # Repeated candidate checks must restore the same caller settings.
        assert wrapped(*arguments) == result
        assert namespace.verify_equivalence is wrapped
    assert namespace.verify_equivalence is original
    assert _settings() == previous


def _data(size=9, channels=3):
    rng = np.random.default_rng(601)
    count = 8
    burned = np.zeros((count, 1, size, size), dtype=np.float32)
    burned[:, 0, size // 2 - 1, size // 2] = 1
    burned[::2, 0, 0, 0] = 1
    return CachedSplit(
        environment=rng.normal(size=(count, channels, size, size)).astype(np.float32),
        burned=burned, target=(np.arange(count) % 2).astype(np.float32),
        weight=np.ones(count, dtype=np.float64),
        event_index=np.zeros(count, dtype=np.int64), time_utc=np.full(count, 3600, dtype=np.int64),
        row=np.arange(count, dtype=np.int64), col=np.zeros(count, dtype=np.int64),
    )


def _candidate(family):
    return next(candidate for candidate in search.candidate_plan(
        learning_rates=(0.003,), schedules=("constant",),
    ) if candidate["family"] == family and candidate["kernel_size"] == 9)


@pytest.mark.parametrize("mismatch", [False, True])
def test_real_verification_preserves_parameters_and_rng_and_rejects_mismatch(monkeypatch, mismatch):
    # Use actual model/cache paths on CPU under the CUDA policy. This tests the
    # assertion rather than mocking it, and runs without an NVIDIA device.
    torch.manual_seed(613)
    data = _data()
    mean, std = np.zeros(3, dtype=np.float32), np.ones(3, dtype=np.float32)
    model = search.build(_candidate("cnn"), 3, torch.device("cpu")).eval()
    state = {name: value.detach().clone() for name, value in model.state_dict().items()}
    cpu_rng = torch.get_rng_state().clone()
    original_verification = search.verify_equivalence
    if mismatch:
        cached = search.cached_probability
        monkeypatch.setattr(search, "cached_probability", lambda *args: cached(*args) + 0.02)

    def original(model_arg, data_arg, mean_arg, std_arg, family_arg, device_arg):
        assert torch.device(device_arg).type == "cuda"
        return original_verification(model_arg, data_arg, mean_arg, std_arg, family_arg, torch.device("cpu"))

    namespace = SimpleNamespace(verify_equivalence=original)
    torch.set_float32_matmul_precision("high")
    previous = _settings()

    def exercise():
        with strict_cuda_equivalence(namespace):
            return namespace.verify_equivalence(model, data, mean, std, "cnn", torch.device("cuda"))

    if mismatch:
        with pytest.raises(AssertionError, match="Cached/public model mismatch"):
            exercise()
    else:
        result = exercise()
        assert result["device_float32_max_error"] < 2e-6
        assert result["cpu_float64_max_error"] < 1e-12
    assert namespace.verify_equivalence is original
    assert _settings() == previous
    assert torch.equal(torch.get_rng_state(), cpu_rng)
    for name, value in model.state_dict().items():
        assert torch.equal(value, state[name]), name
    assert search.verify_equivalence is original_verification


def test_scoped_callable_restored_after_dispatch_exception():
    original = lambda *args: {}
    namespace = SimpleNamespace(verify_equivalence=original)
    with pytest.raises(RuntimeError, match="dispatch failure"):
        with strict_cuda_equivalence(namespace):
            assert namespace.verify_equivalence is not original
            raise RuntimeError("dispatch failure")
    assert namespace.verify_equivalence is original


@pytest.mark.skipif(not torch.cuda.is_available(), reason="An NVIDIA CUDA device is not available")
@pytest.mark.parametrize("family", ["constant", "linear", "legacy", "cnn", "mlp", "residual_mlp", "mixed", "neural_mixed"])
def test_real_cuda_family_equivalence_and_state_preservation(family):
    torch.manual_seed(629)
    device = torch.device("cuda")
    data = _data(channels=19)
    mean, std = np.zeros(19, dtype=np.float32), np.ones(19, dtype=np.float32)
    model = search.build(_candidate(family), 19, device).eval()
    # Keep sparse-contact predictions away from saturation and make learned
    # output weights nonzero, unlike the search's uniform-rate initialization.
    with torch.no_grad():
        for name, parameter in model.named_parameters():
            if name.endswith("output.bias") or name == "kernel_network.2.bias":
                parameter.fill_(-3.0)
        if family == "neural_mixed":
            model.combiner[-1].weight.normal_(std=0.1)
    state = {name: value.detach().clone() for name, value in model.state_dict().items()}
    cpu_rng = torch.get_rng_state().clone()
    cuda_rng = [value.clone() for value in torch.cuda.get_rng_state_all()]
    torch.set_float32_matmul_precision("high")
    torch.backends.cudnn.allow_tf32 = True
    previous = _settings()
    original = search.verify_equivalence
    with strict_cuda_equivalence(search):
        result = search.verify_equivalence(model, data, mean, std, family, device)
    assert search.verify_equivalence is original
    assert "cuda_verification_precision" in result
    assert result["cpu_float64_max_error"] < 1e-12
    assert _settings() == previous
    assert torch.equal(torch.get_rng_state(), cpu_rng)
    assert all(torch.equal(left, right) for left, right in zip(cuda_rng, torch.cuda.get_rng_state_all(), strict=True))
    for name, value in model.state_dict().items():
        assert torch.equal(value, state[name]), name
