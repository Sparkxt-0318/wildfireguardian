"""A post-training verification failure must preserve resumable state."""

import json
import os
from pathlib import Path
import sys

import numpy as np
import pytest
import torch

from wildfire_burned_area_hourly.probability_model import kernel_search_multiscale as search
from wildfire_burned_area_hourly.probability_model import kernel_search_portable as portable
from wildfire_burned_area_hourly.probability_model.cache import CachedSplit, fit_normalization
from wildfire_burned_area_hourly.probability_model.cuda_equivalence import strict_cuda_equivalence
from wildfire_burned_area_hourly.probability_model.train import fit_global_rate


@pytest.fixture(autouse=True)
def _one_cpu_thread():
    previous = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(previous)


def _split(seed, event_index):
    rng = np.random.default_rng(seed)
    count = 24
    burned = np.zeros((count, 1, 9, 9), dtype=np.float32)
    burned[:, 0, 3, 4] = 1
    burned[::3, 0, 4, 5] = 1
    return CachedSplit(
        environment=rng.normal(size=(count, 2, 9, 9)).astype(np.float32),
        burned=burned,
        target=(np.arange(count) % 3 == 0).astype(np.float32),
        weight=np.where(np.arange(count) % 4, 1, 7).astype(np.float64),
        event_index=np.full(count, event_index, dtype=np.int64),
        time_utc=np.full(count, 3600, dtype=np.int64),
        row=np.arange(count, dtype=np.int64),
        col=np.full(count, 10, dtype=np.int64),
    )


def _equal_nested(first, second):
    if isinstance(first, torch.Tensor):
        torch.testing.assert_close(first, second, rtol=0, atol=0)
    elif isinstance(first, dict):
        assert first.keys() == second.keys()
        for key in first:
            _equal_nested(first[key], second[key])
    elif isinstance(first, (tuple, list)):
        assert len(first) == len(second)
        for left, right in zip(first, second, strict=True):
            _equal_nested(left, right)
    else:
        assert first == second


def test_selected_checkpoint_failure_resumes_without_another_optimizer_step(tmp_path, monkeypatch):
    cache = tmp_path / "cache"
    cache.mkdir()
    metadata = dict(
        dt_hours=1.0, kernel_size=9,
        channels=["weather.temperature_2m", "terrain.slope_degrees"],
        event_ids=["train_event", "validation_event", "test_event"],
        splits={"train_event": "train", "validation_event": "validation", "test_event": "test"},
        data_root=str(cache), source_files=[],
    )
    (cache / "metadata.json").write_text(json.dumps(metadata))
    data = [_split(801 + index, index) for index in range(3)]
    for split, partition in zip(("train", "validation", "test"), data, strict=True):
        np.savez(cache / f"{split}.npz", **vars(partition))

    output = tmp_path / "same_output"
    options = dict(learning_rates=(0.03,), schedules=("constant",), warmup_epochs=1,
                   minimum_lr_factor=0.1, restart_period=2)
    protocol = search.setup(output, cache, 2, 2, 71, **options)
    candidate = next(item for item in protocol["candidates"]
                     if item["family"] == "neural_mixed" and item["hidden_channels"] == 32)
    assert candidate["dropout"] > 0 and candidate["combiner_dropout"] > 0
    folder = output / "candidates" / candidate["id"]
    device = torch.device("cpu")
    train, validation = data[:2]
    mean, std = fit_normalization(train)
    tensors = search.tensor_data(train, mean, std, candidate["family"], device)
    vt = search.tensor_data(validation, mean, std, candidate["family"], device)
    baseline = fit_global_rate(train)
    protocol_bytes = (output / "protocol.json").read_bytes()
    source_snapshot = {path: path.read_bytes() for path in (output / "source_snapshot").rglob("*")
                       if path.is_file()}
    frozen_source = {
        Path(search.__file__).parent / name: (Path(search.__file__).parent / name).read_bytes()
        for name in protocol["training_source_sha256"]
    }

    optimizer_steps = []
    real_step = torch.optim.AdamW.step

    def counted_step(optimizer, *args, **kwargs):
        optimizer_steps.append(1)
        return real_step(optimizer, *args, **kwargs)

    monkeypatch.setattr(torch.optim.AdamW, "step", counted_step)
    real_verify = search.verify_equivalence
    verification_calls = []

    def fail_after_committed_final_epoch(*args, **kwargs):
        result = real_verify(*args, **kwargs)
        verification_calls.append(result)
        if len(verification_calls) == 2:
            assert (folder / "last.pt").is_file()
            assert len(json.loads((folder / "history.json").read_text())) == 2
            assert not (folder / "summary.json").exists()
            raise AssertionError("Simulated selected-checkpoint equivalence failure")
        return result

    monkeypatch.setattr(search, "verify_equivalence", fail_after_committed_final_epoch)
    with pytest.raises(AssertionError, match="Simulated selected-checkpoint"):
        with strict_cuda_equivalence(search):
            search.fit_candidate(candidate, train, validation, tensors, vt, mean, std, baseline,
                                 metadata, protocol, output, device, 2)
    assert search.verify_equivalence is fail_after_committed_final_epoch
    assert len(optimizer_steps) == 2
    history_bytes = (folder / "history.json").read_bytes()
    last_bytes = (folder / "last.pt").read_bytes()
    saved = torch.load(folder / "last.pt", weights_only=True)
    selected = torch.load(folder / "checkpoint.pt", weights_only=True)
    assert saved["epoch"] == 2 and saved["next_optimizer_step"] == 3
    assert all(int(state["step"]) == 2 for state in saved["optimizer_state_dict"]["state"].values())
    _equal_nested(saved["best_checkpoint"], selected)

    # The actual frozen setup must accept the same output and source/cache hashes.
    resumed_protocol = search.setup(output, cache, 2, 2, 71, **options)
    assert resumed_protocol == protocol
    monkeypatch.setattr(search, "verify_equivalence", real_verify)
    with strict_cuda_equivalence(search):
        summary = search.fit_candidate(candidate, train, validation, tensors, vt, mean, std, baseline,
                                       metadata, resumed_protocol, output, device, 2)
    assert search.verify_equivalence is real_verify
    assert len(optimizer_steps) == 2
    assert summary["epochs_completed"] == 2 and summary["best_epoch"] == selected["best_epoch"]
    assert summary["validation_common_brier"] == saved["best_validation_brier"]
    assert (folder / "history.json").read_bytes() == history_bytes
    assert (folder / "last.pt").read_bytes() == last_bytes
    resumed_state = torch.load(folder / "last.pt", weights_only=True)
    for key in ("model_state_dict", "optimizer_state_dict", "cpu_rng_state", "best_checkpoint"):
        _equal_nested(resumed_state[key], saved[key])
    _equal_nested(torch.load(folder / "checkpoint.pt", weights_only=True), selected)
    assert (output / "protocol.json").read_bytes() == protocol_bytes
    assert {path: path.read_bytes() for path in source_snapshot} == source_snapshot
    assert {path: path.read_bytes() for path in frozen_source} == frozen_source
    search.verify_protocol(resumed_protocol, cache)


def test_portable_dispatch_restores_verifier_when_a_stage_raises(monkeypatch):
    monkeypatch.setattr(sys, "argv", ["portable_search", "train", "--device", "cpu"])
    monkeypatch.setattr(portable, "prepare_args", lambda args: args)
    original = search.verify_equivalence

    def failed_stage(args):
        assert args.stage == "train"
        assert search.verify_equivalence is not original
        raise RuntimeError("Simulated stage failure")

    monkeypatch.setattr(search, "train_search", failed_stage)
    with pytest.raises(RuntimeError, match="Simulated stage failure"):
        portable.main()
    assert search.verify_equivalence is original


@pytest.mark.parametrize("explicit", [False, True])
def test_precision_entry_forwards_original_arguments_and_preserves_environment(monkeypatch, tmp_path, explicit):
    from wildfire_burned_area_hourly import precision_search

    keys = ("PYTORCH_ENABLE_MPS_FALLBACK", "OPENBLAS_NUM_THREADS")
    expected = {keys[0]: "0", keys[1]: "8"} if explicit else dict.fromkeys(keys, "1")
    for key in keys:
        if explicit:
            monkeypatch.setenv(key, expected[key])
        else:
            monkeypatch.delenv(key, raising=False)
    argv = [
        "precision_search", "run", "--cache", str(tmp_path / "fresh_cache"),
        "--output", str(tmp_path / "existing_output"), "--device", "cuda:0",
        "--epochs", "512", "--finalist-epochs", "4096", "--seed", "7",
        "--learning-rates", "0.001", "0.003", "0.01", "0.03",
        "--schedules", "constant", "warmup_cosine", "--warmup-epochs", "32",
        "--minimum-lr-factor", "0.01", "--threads", "2",
    ]
    expected_argv = argv.copy()
    monkeypatch.setattr(sys, "argv", argv)
    original = search.verify_equivalence
    captured = []

    def original_main():
        assert sys.argv is argv and sys.argv == expected_argv
        assert {key: os.environ[key] for key in keys} == expected
        assert search.verify_equivalence is not original
        captured.append(search.parser().parse_args())

    monkeypatch.setattr(search, "main", original_main)
    precision_search.main()
    assert search.verify_equivalence is original
    assert len(captured) == 1
    actual, expected_args = vars(captured[0]), vars(search.parser().parse_args(expected_argv[1:]))
    assert actual == expected_args
    assert actual["cache"] == tmp_path / "fresh_cache"
    assert actual["device"] == "cuda:0"
    assert {key: os.environ[key] for key in keys} == expected
    assert not (tmp_path / "fresh_cache").exists()
    assert not (tmp_path / "existing_output").exists()


@pytest.mark.parametrize("failure", [SystemExit(2), RuntimeError("Original driver failure")])
def test_precision_entry_restores_scoped_verifier_when_original_main_raises(monkeypatch, failure):
    from wildfire_burned_area_hourly import precision_search

    original = search.verify_equivalence
    precision = (
        torch.backends.cudnn.allow_tf32,
        torch.backends.cuda.matmul.allow_tf32,
        torch.get_float32_matmul_precision(),
    )

    def original_main():
        assert search.verify_equivalence is not original
        raise failure

    monkeypatch.setattr(search, "main", original_main)
    with pytest.raises(type(failure)) as caught:
        precision_search.main()
    assert caught.value is failure
    assert search.verify_equivalence is original
    assert (
        torch.backends.cudnn.allow_tf32,
        torch.backends.cuda.matmul.allow_tf32,
        torch.get_float32_matmul_precision(),
    ) == precision
