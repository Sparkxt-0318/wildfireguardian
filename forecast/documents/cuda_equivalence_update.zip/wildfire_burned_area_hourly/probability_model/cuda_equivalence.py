"""Strict CUDA verification without changing a resumed training trajectory.

The frozen search compares a flattened linear path with public convolutions.
PyTorch 2.5 permits TF32 separately for those operations. Use full float32
arithmetic for that comparison, then restore the caller's training settings.
The existing float32 tolerances and CPU float64 reference remain unchanged.
"""
from __future__ import annotations

from contextlib import contextmanager
from functools import wraps
import os

import torch


@contextmanager
def full_precision_cuda_verification():
    """Temporarily disable TF32; restore all changed settings on every exit."""
    if os.environ.get("TORCH_ALLOW_TF32_CUBLAS_OVERRIDE") == "1":
        raise RuntimeError(
            "Strict CUDA verification requires TORCH_ALLOW_TF32_CUBLAS_OVERRIDE "
            "to be unset or 0; its value 1 forces reduced-precision matrix multiplication."
        )
    previous = dict(
        cudnn_allow_tf32=torch.backends.cudnn.allow_tf32,
        matmul_allow_tf32=torch.backends.cuda.matmul.allow_tf32,
        float32_matmul_precision=torch.get_float32_matmul_precision(),
    )
    try:
        torch.backends.cudnn.allow_tf32 = False
        torch.set_float32_matmul_precision("highest")
        torch.backends.cuda.matmul.allow_tf32 = False
        yield previous
    finally:
        torch.backends.cuda.matmul.allow_tf32 = previous["matmul_allow_tf32"]
        # In PyTorch 2.5, assigning allow_tf32=True changes "medium" to
        # "high". Restore the named policy last to retain it exactly.
        torch.set_float32_matmul_precision(previous["float32_matmul_precision"])
        torch.backends.cudnn.allow_tf32 = previous["cudnn_allow_tf32"]


@contextmanager
def strict_cuda_equivalence(search):
    """Scope the portable runner's verification override to one dispatch.

    No frozen source, model parameter, optimizer, RNG or tolerance is edited.
    CPU/MPS checks delegate directly to the original implementation.
    """
    original = search.verify_equivalence

    @wraps(original)
    def verify(model, data, mean, std, family, device):
        if torch.device(device).type != "cuda":
            return original(model, data, mean, std, family, device)
        with full_precision_cuda_verification() as previous:
            try:
                result = original(model, data, mean, std, family, device)
            except AssertionError as error:
                raise AssertionError(
                    f"{error} (family={family}, device={device}; CUDA verification "
                    "used highest float32 matmul precision with both TF32 flags disabled)"
                ) from error
        return {
            **result,
            "cuda_verification_precision": {
                "policy": "Full float32 for equivalence only; original tolerances retained",
                "cudnn_allow_tf32": False,
                "matmul_allow_tf32": False,
                "float32_matmul_precision": "highest",
                "training_settings_restored": previous,
            },
        }

    search.verify_equivalence = verify
    try:
        yield
    finally:
        search.verify_equivalence = original
