"""Run a locally prepared multiscale cache with strict CUDA verification.

Unlike portable_search, this entry accepts any locally prepared cache and does
not relocate data. All search arguments and frozen training sources are retained.
"""
from __future__ import annotations

import os


def main():
    os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")
    os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
    from .probability_model import kernel_search_multiscale as search
    from .probability_model.cuda_equivalence import strict_cuda_equivalence

    with strict_cuda_equivalence(search):
        search.main()


if __name__ == "__main__":
    main()
